/**
 */
package dMNTable;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entry</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.Entry#getValue <em>Value</em>}</li>
 *   <li>{@link dMNTable.Entry#getRuleAssignedEntry <em>Rule Assigned Entry</em>}</li>
 * </ul>
 *
 * @see dMNTable.DMNTablePackage#getEntry()
 * @model
 * @generated
 */
public interface Entry extends EObject {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(String)
	 * @see dMNTable.DMNTablePackage#getEntry_Value()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getValue();

	/**
	 * Sets the value of the '{@link dMNTable.Entry#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(String value);

	/**
	 * Returns the value of the '<em><b>Rule Assigned Entry</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link dMNTable.Rule#getEntry <em>Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rule Assigned Entry</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rule Assigned Entry</em>' reference.
	 * @see #setRuleAssignedEntry(Rule)
	 * @see dMNTable.DMNTablePackage#getEntry_RuleAssignedEntry()
	 * @see dMNTable.Rule#getEntry
	 * @model opposite="entry" required="true"
	 * @generated
	 */
	Rule getRuleAssignedEntry();

	/**
	 * Sets the value of the '{@link dMNTable.Entry#getRuleAssignedEntry <em>Rule Assigned Entry</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rule Assigned Entry</em>' reference.
	 * @see #getRuleAssignedEntry()
	 * @generated
	 */
	void setRuleAssignedEntry(Rule value);

} // Entry
