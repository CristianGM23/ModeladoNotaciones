/**
 */
package dMNTable;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Clause</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.InputClause#getEntriesInputClause <em>Entries Input Clause</em>}</li>
 * </ul>
 *
 * @see dMNTable.DMNTablePackage#getInputClause()
 * @model
 * @generated
 */
public interface InputClause extends Clause {
	/**
	 * Returns the value of the '<em><b>Entries Input Clause</b></em>' containment reference list.
	 * The list contents are of type {@link dMNTable.Entry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entries Input Clause</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entries Input Clause</em>' containment reference list.
	 * @see dMNTable.DMNTablePackage#getInputClause_EntriesInputClause()
	 * @model containment="true"
	 * @generated
	 */
	EList<Entry> getEntriesInputClause();

} // InputClause
