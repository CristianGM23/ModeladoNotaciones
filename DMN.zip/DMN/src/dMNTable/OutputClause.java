/**
 */
package dMNTable;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Clause</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.OutputClause#getEntriesOutputClause <em>Entries Output Clause</em>}</li>
 * </ul>
 *
 * @see dMNTable.DMNTablePackage#getOutputClause()
 * @model
 * @generated
 */
public interface OutputClause extends Clause {
	/**
	 * Returns the value of the '<em><b>Entries Output Clause</b></em>' containment reference list.
	 * The list contents are of type {@link dMNTable.Entry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entries Output Clause</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entries Output Clause</em>' containment reference list.
	 * @see dMNTable.DMNTablePackage#getOutputClause_EntriesOutputClause()
	 * @model containment="true"
	 * @generated
	 */
	EList<Entry> getEntriesOutputClause();

} // OutputClause
