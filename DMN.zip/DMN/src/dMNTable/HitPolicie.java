/**
 */
package dMNTable;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hit Policie</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.HitPolicie#getType <em>Type</em>}</li>
 *   <li>{@link dMNTable.HitPolicie#getRule <em>Rule</em>}</li>
 * </ul>
 *
 * @see dMNTable.DMNTablePackage#getHitPolicie()
 * @model
 * @generated
 */
public interface HitPolicie extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link dMNTable.TypeHitPolicie}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see dMNTable.TypeHitPolicie
	 * @see #setType(TypeHitPolicie)
	 * @see dMNTable.DMNTablePackage#getHitPolicie_Type()
	 * @model
	 * @generated
	 */
	TypeHitPolicie getType();

	/**
	 * Sets the value of the '{@link dMNTable.HitPolicie#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see dMNTable.TypeHitPolicie
	 * @see #getType()
	 * @generated
	 */
	void setType(TypeHitPolicie value);

	/**
	 * Returns the value of the '<em><b>Rule</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link dMNTable.Rule#getHitpolicie <em>Hitpolicie</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rule</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rule</em>' reference.
	 * @see #setRule(Rule)
	 * @see dMNTable.DMNTablePackage#getHitPolicie_Rule()
	 * @see dMNTable.Rule#getHitpolicie
	 * @model opposite="hitpolicie" required="true"
	 * @generated
	 */
	Rule getRule();

	/**
	 * Sets the value of the '{@link dMNTable.HitPolicie#getRule <em>Rule</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rule</em>' reference.
	 * @see #getRule()
	 * @generated
	 */
	void setRule(Rule value);

} // HitPolicie
