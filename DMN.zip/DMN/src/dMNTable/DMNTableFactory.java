/**
 */
package dMNTable;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see dMNTable.DMNTablePackage
 * @generated
 */
public interface DMNTableFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DMNTableFactory eINSTANCE = dMNTable.impl.DMNTableFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>DMN Table</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DMN Table</em>'.
	 * @generated
	 */
	DMNTable createDMNTable();

	/**
	 * Returns a new object of class '<em>Input Clause</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input Clause</em>'.
	 * @generated
	 */
	InputClause createInputClause();

	/**
	 * Returns a new object of class '<em>Output Clause</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Output Clause</em>'.
	 * @generated
	 */
	OutputClause createOutputClause();

	/**
	 * Returns a new object of class '<em>Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rule</em>'.
	 * @generated
	 */
	Rule createRule();

	/**
	 * Returns a new object of class '<em>Annotation Clause</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Annotation Clause</em>'.
	 * @generated
	 */
	AnnotationClause createAnnotationClause();

	/**
	 * Returns a new object of class '<em>Hit Policie</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hit Policie</em>'.
	 * @generated
	 */
	HitPolicie createHitPolicie();

	/**
	 * Returns a new object of class '<em>Entry</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Entry</em>'.
	 * @generated
	 */
	Entry createEntry();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	DMNTablePackage getDMNTablePackage();

} //DMNTableFactory
