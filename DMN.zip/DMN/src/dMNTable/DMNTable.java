/**
 */
package dMNTable;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DMN Table</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.DMNTable#getElements <em>Elements</em>}</li>
 *   <li>{@link dMNTable.DMNTable#getName <em>Name</em>}</li>
 *   <li>{@link dMNTable.DMNTable#getHitpolicie <em>Hitpolicie</em>}</li>
 * </ul>
 *
 * @see dMNTable.DMNTablePackage#getDMNTable()
 * @model
 * @generated
 */
public interface DMNTable extends EObject {
	/**
	 * Returns the value of the '<em><b>Elements</b></em>' containment reference list.
	 * The list contents are of type {@link dMNTable.Elements}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Elements</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elements</em>' containment reference list.
	 * @see dMNTable.DMNTablePackage#getDMNTable_Elements()
	 * @model containment="true"
	 * @generated
	 */
	EList<Elements> getElements();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see dMNTable.DMNTablePackage#getDMNTable_Name()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link dMNTable.DMNTable#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Hitpolicie</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hitpolicie</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hitpolicie</em>' containment reference.
	 * @see #setHitpolicie(HitPolicie)
	 * @see dMNTable.DMNTablePackage#getDMNTable_Hitpolicie()
	 * @model containment="true"
	 * @generated
	 */
	HitPolicie getHitpolicie();

	/**
	 * Sets the value of the '{@link dMNTable.DMNTable#getHitpolicie <em>Hitpolicie</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hitpolicie</em>' containment reference.
	 * @see #getHitpolicie()
	 * @generated
	 */
	void setHitpolicie(HitPolicie value);

} // DMNTable
