/**
 */
package dMNTable;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.Rule#getClause <em>Clause</em>}</li>
 *   <li>{@link dMNTable.Rule#getAnnotationclause <em>Annotationclause</em>}</li>
 *   <li>{@link dMNTable.Rule#getHitpolicie <em>Hitpolicie</em>}</li>
 *   <li>{@link dMNTable.Rule#getEntry <em>Entry</em>}</li>
 * </ul>
 *
 * @see dMNTable.DMNTablePackage#getRule()
 * @model
 * @generated
 */
public interface Rule extends Elements {
	/**
	 * Returns the value of the '<em><b>Clause</b></em>' containment reference list.
	 * The list contents are of type {@link dMNTable.Clause}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Clause</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clause</em>' containment reference list.
	 * @see dMNTable.DMNTablePackage#getRule_Clause()
	 * @model containment="true"
	 * @generated
	 */
	EList<Clause> getClause();

	/**
	 * Returns the value of the '<em><b>Annotationclause</b></em>' reference list.
	 * The list contents are of type {@link dMNTable.AnnotationClause}.
	 * It is bidirectional and its opposite is '{@link dMNTable.AnnotationClause#getRule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Annotationclause</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Annotationclause</em>' reference list.
	 * @see dMNTable.DMNTablePackage#getRule_Annotationclause()
	 * @see dMNTable.AnnotationClause#getRule
	 * @model opposite="rule"
	 * @generated
	 */
	EList<AnnotationClause> getAnnotationclause();

	/**
	 * Returns the value of the '<em><b>Hitpolicie</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link dMNTable.HitPolicie#getRule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hitpolicie</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hitpolicie</em>' reference.
	 * @see #setHitpolicie(HitPolicie)
	 * @see dMNTable.DMNTablePackage#getRule_Hitpolicie()
	 * @see dMNTable.HitPolicie#getRule
	 * @model opposite="rule" required="true"
	 * @generated
	 */
	HitPolicie getHitpolicie();

	/**
	 * Sets the value of the '{@link dMNTable.Rule#getHitpolicie <em>Hitpolicie</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hitpolicie</em>' reference.
	 * @see #getHitpolicie()
	 * @generated
	 */
	void setHitpolicie(HitPolicie value);

	/**
	 * Returns the value of the '<em><b>Entry</b></em>' reference list.
	 * The list contents are of type {@link dMNTable.Entry}.
	 * It is bidirectional and its opposite is '{@link dMNTable.Entry#getRuleAssignedEntry <em>Rule Assigned Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entry</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entry</em>' reference list.
	 * @see dMNTable.DMNTablePackage#getRule_Entry()
	 * @see dMNTable.Entry#getRuleAssignedEntry
	 * @model opposite="ruleAssignedEntry" required="true"
	 * @generated
	 */
	EList<Entry> getEntry();

} // Rule
