/**
 */
package dMNTable;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clause</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMNTable.DMNTablePackage#getClause()
 * @model abstract="true"
 * @generated
 */
public interface Clause extends Elements {
} // Clause
