/**
 */
package dMNTable.impl;

import dMNTable.DMNTablePackage;
import dMNTable.Entry;
import dMNTable.InputClause;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Clause</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.impl.InputClauseImpl#getEntriesInputClause <em>Entries Input Clause</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InputClauseImpl extends ClauseImpl implements InputClause {
	/**
	 * The cached value of the '{@link #getEntriesInputClause() <em>Entries Input Clause</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntriesInputClause()
	 * @generated
	 * @ordered
	 */
	protected EList<Entry> entriesInputClause;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InputClauseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNTablePackage.Literals.INPUT_CLAUSE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Entry> getEntriesInputClause() {
		if (entriesInputClause == null) {
			entriesInputClause = new EObjectContainmentEList<Entry>(Entry.class, this, DMNTablePackage.INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE);
		}
		return entriesInputClause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DMNTablePackage.INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE:
				return ((InternalEList<?>)getEntriesInputClause()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DMNTablePackage.INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE:
				return getEntriesInputClause();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DMNTablePackage.INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE:
				getEntriesInputClause().clear();
				getEntriesInputClause().addAll((Collection<? extends Entry>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case DMNTablePackage.INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE:
				getEntriesInputClause().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DMNTablePackage.INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE:
				return entriesInputClause != null && !entriesInputClause.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //InputClauseImpl
