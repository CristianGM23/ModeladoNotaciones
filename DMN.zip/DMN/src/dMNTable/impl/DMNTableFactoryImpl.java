/**
 */
package dMNTable.impl;

import dMNTable.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DMNTableFactoryImpl extends EFactoryImpl implements DMNTableFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DMNTableFactory init() {
		try {
			DMNTableFactory theDMNTableFactory = (DMNTableFactory)EPackage.Registry.INSTANCE.getEFactory(DMNTablePackage.eNS_URI);
			if (theDMNTableFactory != null) {
				return theDMNTableFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new DMNTableFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNTableFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case DMNTablePackage.DMN_TABLE: return createDMNTable();
			case DMNTablePackage.INPUT_CLAUSE: return createInputClause();
			case DMNTablePackage.OUTPUT_CLAUSE: return createOutputClause();
			case DMNTablePackage.RULE: return createRule();
			case DMNTablePackage.ANNOTATION_CLAUSE: return createAnnotationClause();
			case DMNTablePackage.HIT_POLICIE: return createHitPolicie();
			case DMNTablePackage.ENTRY: return createEntry();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case DMNTablePackage.TYPE_HIT_POLICIE:
				return createTypeHitPolicieFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case DMNTablePackage.TYPE_HIT_POLICIE:
				return convertTypeHitPolicieToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNTable createDMNTable() {
		DMNTableImpl dmnTable = new DMNTableImpl();
		return dmnTable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputClause createInputClause() {
		InputClauseImpl inputClause = new InputClauseImpl();
		return inputClause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OutputClause createOutputClause() {
		OutputClauseImpl outputClause = new OutputClauseImpl();
		return outputClause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rule createRule() {
		RuleImpl rule = new RuleImpl();
		return rule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AnnotationClause createAnnotationClause() {
		AnnotationClauseImpl annotationClause = new AnnotationClauseImpl();
		return annotationClause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HitPolicie createHitPolicie() {
		HitPolicieImpl hitPolicie = new HitPolicieImpl();
		return hitPolicie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entry createEntry() {
		EntryImpl entry = new EntryImpl();
		return entry;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TypeHitPolicie createTypeHitPolicieFromString(EDataType eDataType, String initialValue) {
		TypeHitPolicie result = TypeHitPolicie.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTypeHitPolicieToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNTablePackage getDMNTablePackage() {
		return (DMNTablePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static DMNTablePackage getPackage() {
		return DMNTablePackage.eINSTANCE;
	}

} //DMNTableFactoryImpl
