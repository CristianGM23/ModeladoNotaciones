/**
 */
package dMNTable.impl;

import dMNTable.DMNTablePackage;
import dMNTable.Entry;
import dMNTable.OutputClause;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Clause</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.impl.OutputClauseImpl#getEntriesOutputClause <em>Entries Output Clause</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutputClauseImpl extends ClauseImpl implements OutputClause {
	/**
	 * The cached value of the '{@link #getEntriesOutputClause() <em>Entries Output Clause</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntriesOutputClause()
	 * @generated
	 * @ordered
	 */
	protected EList<Entry> entriesOutputClause;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutputClauseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNTablePackage.Literals.OUTPUT_CLAUSE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Entry> getEntriesOutputClause() {
		if (entriesOutputClause == null) {
			entriesOutputClause = new EObjectContainmentEList<Entry>(Entry.class, this, DMNTablePackage.OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE);
		}
		return entriesOutputClause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DMNTablePackage.OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE:
				return ((InternalEList<?>)getEntriesOutputClause()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DMNTablePackage.OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE:
				return getEntriesOutputClause();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DMNTablePackage.OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE:
				getEntriesOutputClause().clear();
				getEntriesOutputClause().addAll((Collection<? extends Entry>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case DMNTablePackage.OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE:
				getEntriesOutputClause().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DMNTablePackage.OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE:
				return entriesOutputClause != null && !entriesOutputClause.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //OutputClauseImpl
