/**
 */
package dMNTable.impl;

import dMNTable.Clause;
import dMNTable.DMNTablePackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Clause</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ClauseImpl extends ElementsImpl implements Clause {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClauseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNTablePackage.Literals.CLAUSE;
	}

} //ClauseImpl
