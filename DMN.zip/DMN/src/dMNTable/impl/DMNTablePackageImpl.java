/**
 */
package dMNTable.impl;

import dMNTable.AnnotationClause;
import dMNTable.Clause;
import dMNTable.DMNTable;
import dMNTable.DMNTableFactory;
import dMNTable.DMNTablePackage;
import dMNTable.Elements;
import dMNTable.Entry;
import dMNTable.HitPolicie;
import dMNTable.InputClause;
import dMNTable.OutputClause;
import dMNTable.Rule;
import dMNTable.TypeHitPolicie;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DMNTablePackageImpl extends EPackageImpl implements DMNTablePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dmnTableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elementsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inputClauseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass outputClauseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ruleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass annotationClauseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hitPolicieEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass entryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clauseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum typeHitPolicieEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see dMNTable.DMNTablePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DMNTablePackageImpl() {
		super(eNS_URI, DMNTableFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link DMNTablePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DMNTablePackage init() {
		if (isInited) return (DMNTablePackage)EPackage.Registry.INSTANCE.getEPackage(DMNTablePackage.eNS_URI);

		// Obtain or create and register package
		Object registeredDMNTablePackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		DMNTablePackageImpl theDMNTablePackage = registeredDMNTablePackage instanceof DMNTablePackageImpl ? (DMNTablePackageImpl)registeredDMNTablePackage : new DMNTablePackageImpl();

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theDMNTablePackage.createPackageContents();

		// Initialize created meta-data
		theDMNTablePackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDMNTablePackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(DMNTablePackage.eNS_URI, theDMNTablePackage);
		return theDMNTablePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDMNTable() {
		return dmnTableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDMNTable_Elements() {
		return (EReference)dmnTableEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDMNTable_Name() {
		return (EAttribute)dmnTableEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDMNTable_Hitpolicie() {
		return (EReference)dmnTableEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElements() {
		return elementsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getElements_Expression() {
		return (EAttribute)elementsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInputClause() {
		return inputClauseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInputClause_EntriesInputClause() {
		return (EReference)inputClauseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOutputClause() {
		return outputClauseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getOutputClause_EntriesOutputClause() {
		return (EReference)outputClauseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRule() {
		return ruleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRule_Clause() {
		return (EReference)ruleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRule_Annotationclause() {
		return (EReference)ruleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRule_Hitpolicie() {
		return (EReference)ruleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRule_Entry() {
		return (EReference)ruleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAnnotationClause() {
		return annotationClauseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAnnotationClause_Rule() {
		return (EReference)annotationClauseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHitPolicie() {
		return hitPolicieEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHitPolicie_Type() {
		return (EAttribute)hitPolicieEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHitPolicie_Rule() {
		return (EReference)hitPolicieEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEntry() {
		return entryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEntry_Value() {
		return (EAttribute)entryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntry_RuleAssignedEntry() {
		return (EReference)entryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClause() {
		return clauseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTypeHitPolicie() {
		return typeHitPolicieEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNTableFactory getDMNTableFactory() {
		return (DMNTableFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		dmnTableEClass = createEClass(DMN_TABLE);
		createEReference(dmnTableEClass, DMN_TABLE__ELEMENTS);
		createEAttribute(dmnTableEClass, DMN_TABLE__NAME);
		createEReference(dmnTableEClass, DMN_TABLE__HITPOLICIE);

		elementsEClass = createEClass(ELEMENTS);
		createEAttribute(elementsEClass, ELEMENTS__EXPRESSION);

		inputClauseEClass = createEClass(INPUT_CLAUSE);
		createEReference(inputClauseEClass, INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE);

		outputClauseEClass = createEClass(OUTPUT_CLAUSE);
		createEReference(outputClauseEClass, OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE);

		ruleEClass = createEClass(RULE);
		createEReference(ruleEClass, RULE__CLAUSE);
		createEReference(ruleEClass, RULE__ANNOTATIONCLAUSE);
		createEReference(ruleEClass, RULE__HITPOLICIE);
		createEReference(ruleEClass, RULE__ENTRY);

		annotationClauseEClass = createEClass(ANNOTATION_CLAUSE);
		createEReference(annotationClauseEClass, ANNOTATION_CLAUSE__RULE);

		hitPolicieEClass = createEClass(HIT_POLICIE);
		createEAttribute(hitPolicieEClass, HIT_POLICIE__TYPE);
		createEReference(hitPolicieEClass, HIT_POLICIE__RULE);

		entryEClass = createEClass(ENTRY);
		createEAttribute(entryEClass, ENTRY__VALUE);
		createEReference(entryEClass, ENTRY__RULE_ASSIGNED_ENTRY);

		clauseEClass = createEClass(CLAUSE);

		// Create enums
		typeHitPolicieEEnum = createEEnum(TYPE_HIT_POLICIE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		inputClauseEClass.getESuperTypes().add(this.getClause());
		outputClauseEClass.getESuperTypes().add(this.getClause());
		ruleEClass.getESuperTypes().add(this.getElements());
		annotationClauseEClass.getESuperTypes().add(this.getClause());
		clauseEClass.getESuperTypes().add(this.getElements());

		// Initialize classes, features, and operations; add parameters
		initEClass(dmnTableEClass, DMNTable.class, "DMNTable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDMNTable_Elements(), this.getElements(), null, "elements", null, 0, -1, DMNTable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDMNTable_Name(), theXMLTypePackage.getString(), "name", null, 0, 1, DMNTable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDMNTable_Hitpolicie(), this.getHitPolicie(), null, "hitpolicie", null, 0, 1, DMNTable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(elementsEClass, Elements.class, "Elements", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getElements_Expression(), ecorePackage.getEString(), "expression", null, 0, 1, Elements.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(inputClauseEClass, InputClause.class, "InputClause", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInputClause_EntriesInputClause(), this.getEntry(), null, "entriesInputClause", null, 0, -1, InputClause.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(outputClauseEClass, OutputClause.class, "OutputClause", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getOutputClause_EntriesOutputClause(), this.getEntry(), null, "entriesOutputClause", null, 0, -1, OutputClause.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ruleEClass, Rule.class, "Rule", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRule_Clause(), this.getClause(), null, "clause", null, 0, -1, Rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRule_Annotationclause(), this.getAnnotationClause(), this.getAnnotationClause_Rule(), "annotationclause", null, 0, -1, Rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRule_Hitpolicie(), this.getHitPolicie(), this.getHitPolicie_Rule(), "hitpolicie", null, 1, 1, Rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRule_Entry(), this.getEntry(), this.getEntry_RuleAssignedEntry(), "entry", null, 1, -1, Rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(annotationClauseEClass, AnnotationClause.class, "AnnotationClause", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAnnotationClause_Rule(), this.getRule(), this.getRule_Annotationclause(), "rule", null, 1, 1, AnnotationClause.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(hitPolicieEClass, HitPolicie.class, "HitPolicie", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHitPolicie_Type(), this.getTypeHitPolicie(), "type", null, 0, 1, HitPolicie.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHitPolicie_Rule(), this.getRule(), this.getRule_Hitpolicie(), "rule", null, 1, 1, HitPolicie.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(entryEClass, Entry.class, "Entry", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEntry_Value(), theXMLTypePackage.getString(), "value", null, 0, 1, Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntry_RuleAssignedEntry(), this.getRule(), this.getRule_Entry(), "ruleAssignedEntry", null, 1, 1, Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(clauseEClass, Clause.class, "Clause", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(typeHitPolicieEEnum, TypeHitPolicie.class, "TypeHitPolicie");
		addEEnumLiteral(typeHitPolicieEEnum, TypeHitPolicie.UNIQUE);
		addEEnumLiteral(typeHitPolicieEEnum, TypeHitPolicie.ANY);
		addEEnumLiteral(typeHitPolicieEEnum, TypeHitPolicie.PRIORITY);
		addEEnumLiteral(typeHitPolicieEEnum, TypeHitPolicie.FIRST);
		addEEnumLiteral(typeHitPolicieEEnum, TypeHitPolicie.OUTPUT_ORDER);
		addEEnumLiteral(typeHitPolicieEEnum, TypeHitPolicie.RULE_ORDER);
		addEEnumLiteral(typeHitPolicieEEnum, TypeHitPolicie.COLLECT);

		// Create resource
		createResource(eNS_URI);
	}

} //DMNTablePackageImpl
