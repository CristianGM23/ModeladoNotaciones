/**
 */
package dMNTable.impl;

import dMNTable.AnnotationClause;
import dMNTable.Clause;
import dMNTable.DMNTablePackage;
import dMNTable.Entry;
import dMNTable.HitPolicie;
import dMNTable.Rule;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.impl.RuleImpl#getClause <em>Clause</em>}</li>
 *   <li>{@link dMNTable.impl.RuleImpl#getAnnotationclause <em>Annotationclause</em>}</li>
 *   <li>{@link dMNTable.impl.RuleImpl#getHitpolicie <em>Hitpolicie</em>}</li>
 *   <li>{@link dMNTable.impl.RuleImpl#getEntry <em>Entry</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RuleImpl extends ElementsImpl implements Rule {
	/**
	 * The cached value of the '{@link #getClause() <em>Clause</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClause()
	 * @generated
	 * @ordered
	 */
	protected EList<Clause> clause;

	/**
	 * The cached value of the '{@link #getAnnotationclause() <em>Annotationclause</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnnotationclause()
	 * @generated
	 * @ordered
	 */
	protected EList<AnnotationClause> annotationclause;

	/**
	 * The cached value of the '{@link #getHitpolicie() <em>Hitpolicie</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHitpolicie()
	 * @generated
	 * @ordered
	 */
	protected HitPolicie hitpolicie;

	/**
	 * The cached value of the '{@link #getEntry() <em>Entry</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntry()
	 * @generated
	 * @ordered
	 */
	protected EList<Entry> entry;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNTablePackage.Literals.RULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Clause> getClause() {
		if (clause == null) {
			clause = new EObjectContainmentEList<Clause>(Clause.class, this, DMNTablePackage.RULE__CLAUSE);
		}
		return clause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AnnotationClause> getAnnotationclause() {
		if (annotationclause == null) {
			annotationclause = new EObjectWithInverseResolvingEList<AnnotationClause>(AnnotationClause.class, this, DMNTablePackage.RULE__ANNOTATIONCLAUSE, DMNTablePackage.ANNOTATION_CLAUSE__RULE);
		}
		return annotationclause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HitPolicie getHitpolicie() {
		if (hitpolicie != null && hitpolicie.eIsProxy()) {
			InternalEObject oldHitpolicie = (InternalEObject)hitpolicie;
			hitpolicie = (HitPolicie)eResolveProxy(oldHitpolicie);
			if (hitpolicie != oldHitpolicie) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DMNTablePackage.RULE__HITPOLICIE, oldHitpolicie, hitpolicie));
			}
		}
		return hitpolicie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HitPolicie basicGetHitpolicie() {
		return hitpolicie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHitpolicie(HitPolicie newHitpolicie, NotificationChain msgs) {
		HitPolicie oldHitpolicie = hitpolicie;
		hitpolicie = newHitpolicie;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, DMNTablePackage.RULE__HITPOLICIE, oldHitpolicie, newHitpolicie);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHitpolicie(HitPolicie newHitpolicie) {
		if (newHitpolicie != hitpolicie) {
			NotificationChain msgs = null;
			if (hitpolicie != null)
				msgs = ((InternalEObject)hitpolicie).eInverseRemove(this, DMNTablePackage.HIT_POLICIE__RULE, HitPolicie.class, msgs);
			if (newHitpolicie != null)
				msgs = ((InternalEObject)newHitpolicie).eInverseAdd(this, DMNTablePackage.HIT_POLICIE__RULE, HitPolicie.class, msgs);
			msgs = basicSetHitpolicie(newHitpolicie, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DMNTablePackage.RULE__HITPOLICIE, newHitpolicie, newHitpolicie));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Entry> getEntry() {
		if (entry == null) {
			entry = new EObjectWithInverseResolvingEList<Entry>(Entry.class, this, DMNTablePackage.RULE__ENTRY, DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY);
		}
		return entry;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DMNTablePackage.RULE__ANNOTATIONCLAUSE:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getAnnotationclause()).basicAdd(otherEnd, msgs);
			case DMNTablePackage.RULE__HITPOLICIE:
				if (hitpolicie != null)
					msgs = ((InternalEObject)hitpolicie).eInverseRemove(this, DMNTablePackage.HIT_POLICIE__RULE, HitPolicie.class, msgs);
				return basicSetHitpolicie((HitPolicie)otherEnd, msgs);
			case DMNTablePackage.RULE__ENTRY:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getEntry()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DMNTablePackage.RULE__CLAUSE:
				return ((InternalEList<?>)getClause()).basicRemove(otherEnd, msgs);
			case DMNTablePackage.RULE__ANNOTATIONCLAUSE:
				return ((InternalEList<?>)getAnnotationclause()).basicRemove(otherEnd, msgs);
			case DMNTablePackage.RULE__HITPOLICIE:
				return basicSetHitpolicie(null, msgs);
			case DMNTablePackage.RULE__ENTRY:
				return ((InternalEList<?>)getEntry()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DMNTablePackage.RULE__CLAUSE:
				return getClause();
			case DMNTablePackage.RULE__ANNOTATIONCLAUSE:
				return getAnnotationclause();
			case DMNTablePackage.RULE__HITPOLICIE:
				if (resolve) return getHitpolicie();
				return basicGetHitpolicie();
			case DMNTablePackage.RULE__ENTRY:
				return getEntry();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DMNTablePackage.RULE__CLAUSE:
				getClause().clear();
				getClause().addAll((Collection<? extends Clause>)newValue);
				return;
			case DMNTablePackage.RULE__ANNOTATIONCLAUSE:
				getAnnotationclause().clear();
				getAnnotationclause().addAll((Collection<? extends AnnotationClause>)newValue);
				return;
			case DMNTablePackage.RULE__HITPOLICIE:
				setHitpolicie((HitPolicie)newValue);
				return;
			case DMNTablePackage.RULE__ENTRY:
				getEntry().clear();
				getEntry().addAll((Collection<? extends Entry>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case DMNTablePackage.RULE__CLAUSE:
				getClause().clear();
				return;
			case DMNTablePackage.RULE__ANNOTATIONCLAUSE:
				getAnnotationclause().clear();
				return;
			case DMNTablePackage.RULE__HITPOLICIE:
				setHitpolicie((HitPolicie)null);
				return;
			case DMNTablePackage.RULE__ENTRY:
				getEntry().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DMNTablePackage.RULE__CLAUSE:
				return clause != null && !clause.isEmpty();
			case DMNTablePackage.RULE__ANNOTATIONCLAUSE:
				return annotationclause != null && !annotationclause.isEmpty();
			case DMNTablePackage.RULE__HITPOLICIE:
				return hitpolicie != null;
			case DMNTablePackage.RULE__ENTRY:
				return entry != null && !entry.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //RuleImpl
