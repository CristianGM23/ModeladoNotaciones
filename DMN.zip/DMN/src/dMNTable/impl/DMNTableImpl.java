/**
 */
package dMNTable.impl;

import dMNTable.DMNTable;
import dMNTable.DMNTablePackage;
import dMNTable.Elements;
import dMNTable.HitPolicie;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>DMN Table</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.impl.DMNTableImpl#getElements <em>Elements</em>}</li>
 *   <li>{@link dMNTable.impl.DMNTableImpl#getName <em>Name</em>}</li>
 *   <li>{@link dMNTable.impl.DMNTableImpl#getHitpolicie <em>Hitpolicie</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DMNTableImpl extends MinimalEObjectImpl.Container implements DMNTable {
	/**
	 * The cached value of the '{@link #getElements() <em>Elements</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElements()
	 * @generated
	 * @ordered
	 */
	protected EList<Elements> elements;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHitpolicie() <em>Hitpolicie</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHitpolicie()
	 * @generated
	 * @ordered
	 */
	protected HitPolicie hitpolicie;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DMNTableImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNTablePackage.Literals.DMN_TABLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Elements> getElements() {
		if (elements == null) {
			elements = new EObjectContainmentEList<Elements>(Elements.class, this, DMNTablePackage.DMN_TABLE__ELEMENTS);
		}
		return elements;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DMNTablePackage.DMN_TABLE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HitPolicie getHitpolicie() {
		return hitpolicie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHitpolicie(HitPolicie newHitpolicie, NotificationChain msgs) {
		HitPolicie oldHitpolicie = hitpolicie;
		hitpolicie = newHitpolicie;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, DMNTablePackage.DMN_TABLE__HITPOLICIE, oldHitpolicie, newHitpolicie);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHitpolicie(HitPolicie newHitpolicie) {
		if (newHitpolicie != hitpolicie) {
			NotificationChain msgs = null;
			if (hitpolicie != null)
				msgs = ((InternalEObject)hitpolicie).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - DMNTablePackage.DMN_TABLE__HITPOLICIE, null, msgs);
			if (newHitpolicie != null)
				msgs = ((InternalEObject)newHitpolicie).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - DMNTablePackage.DMN_TABLE__HITPOLICIE, null, msgs);
			msgs = basicSetHitpolicie(newHitpolicie, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DMNTablePackage.DMN_TABLE__HITPOLICIE, newHitpolicie, newHitpolicie));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DMNTablePackage.DMN_TABLE__ELEMENTS:
				return ((InternalEList<?>)getElements()).basicRemove(otherEnd, msgs);
			case DMNTablePackage.DMN_TABLE__HITPOLICIE:
				return basicSetHitpolicie(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DMNTablePackage.DMN_TABLE__ELEMENTS:
				return getElements();
			case DMNTablePackage.DMN_TABLE__NAME:
				return getName();
			case DMNTablePackage.DMN_TABLE__HITPOLICIE:
				return getHitpolicie();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DMNTablePackage.DMN_TABLE__ELEMENTS:
				getElements().clear();
				getElements().addAll((Collection<? extends Elements>)newValue);
				return;
			case DMNTablePackage.DMN_TABLE__NAME:
				setName((String)newValue);
				return;
			case DMNTablePackage.DMN_TABLE__HITPOLICIE:
				setHitpolicie((HitPolicie)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case DMNTablePackage.DMN_TABLE__ELEMENTS:
				getElements().clear();
				return;
			case DMNTablePackage.DMN_TABLE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case DMNTablePackage.DMN_TABLE__HITPOLICIE:
				setHitpolicie((HitPolicie)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DMNTablePackage.DMN_TABLE__ELEMENTS:
				return elements != null && !elements.isEmpty();
			case DMNTablePackage.DMN_TABLE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case DMNTablePackage.DMN_TABLE__HITPOLICIE:
				return hitpolicie != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //DMNTableImpl
