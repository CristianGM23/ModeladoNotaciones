/**
 */
package dMNTable.impl;

import dMNTable.DMNTablePackage;
import dMNTable.Entry;

import dMNTable.Rule;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entry</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dMNTable.impl.EntryImpl#getValue <em>Value</em>}</li>
 *   <li>{@link dMNTable.impl.EntryImpl#getRuleAssignedEntry <em>Rule Assigned Entry</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EntryImpl extends MinimalEObjectImpl.Container implements Entry {
	/**
	 * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected static final String VALUE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected String value = VALUE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRuleAssignedEntry() <em>Rule Assigned Entry</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRuleAssignedEntry()
	 * @generated
	 * @ordered
	 */
	protected Rule ruleAssignedEntry;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNTablePackage.Literals.ENTRY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(String newValue) {
		String oldValue = value;
		value = newValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DMNTablePackage.ENTRY__VALUE, oldValue, value));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rule getRuleAssignedEntry() {
		if (ruleAssignedEntry != null && ruleAssignedEntry.eIsProxy()) {
			InternalEObject oldRuleAssignedEntry = (InternalEObject)ruleAssignedEntry;
			ruleAssignedEntry = (Rule)eResolveProxy(oldRuleAssignedEntry);
			if (ruleAssignedEntry != oldRuleAssignedEntry) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY, oldRuleAssignedEntry, ruleAssignedEntry));
			}
		}
		return ruleAssignedEntry;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rule basicGetRuleAssignedEntry() {
		return ruleAssignedEntry;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRuleAssignedEntry(Rule newRuleAssignedEntry, NotificationChain msgs) {
		Rule oldRuleAssignedEntry = ruleAssignedEntry;
		ruleAssignedEntry = newRuleAssignedEntry;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY, oldRuleAssignedEntry, newRuleAssignedEntry);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRuleAssignedEntry(Rule newRuleAssignedEntry) {
		if (newRuleAssignedEntry != ruleAssignedEntry) {
			NotificationChain msgs = null;
			if (ruleAssignedEntry != null)
				msgs = ((InternalEObject)ruleAssignedEntry).eInverseRemove(this, DMNTablePackage.RULE__ENTRY, Rule.class, msgs);
			if (newRuleAssignedEntry != null)
				msgs = ((InternalEObject)newRuleAssignedEntry).eInverseAdd(this, DMNTablePackage.RULE__ENTRY, Rule.class, msgs);
			msgs = basicSetRuleAssignedEntry(newRuleAssignedEntry, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY, newRuleAssignedEntry, newRuleAssignedEntry));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY:
				if (ruleAssignedEntry != null)
					msgs = ((InternalEObject)ruleAssignedEntry).eInverseRemove(this, DMNTablePackage.RULE__ENTRY, Rule.class, msgs);
				return basicSetRuleAssignedEntry((Rule)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY:
				return basicSetRuleAssignedEntry(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DMNTablePackage.ENTRY__VALUE:
				return getValue();
			case DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY:
				if (resolve) return getRuleAssignedEntry();
				return basicGetRuleAssignedEntry();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DMNTablePackage.ENTRY__VALUE:
				setValue((String)newValue);
				return;
			case DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY:
				setRuleAssignedEntry((Rule)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case DMNTablePackage.ENTRY__VALUE:
				setValue(VALUE_EDEFAULT);
				return;
			case DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY:
				setRuleAssignedEntry((Rule)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DMNTablePackage.ENTRY__VALUE:
				return VALUE_EDEFAULT == null ? value != null : !VALUE_EDEFAULT.equals(value);
			case DMNTablePackage.ENTRY__RULE_ASSIGNED_ENTRY:
				return ruleAssignedEntry != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (value: ");
		result.append(value);
		result.append(')');
		return result.toString();
	}

} //EntryImpl
