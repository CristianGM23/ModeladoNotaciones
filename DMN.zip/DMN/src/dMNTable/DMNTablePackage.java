/**
 */
package dMNTable;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see dMNTable.DMNTableFactory
 * @model kind="package"
 * @generated
 */
public interface DMNTablePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "dMNTable";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/dMNTable";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "dMNTable";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DMNTablePackage eINSTANCE = dMNTable.impl.DMNTablePackageImpl.init();

	/**
	 * The meta object id for the '{@link dMNTable.impl.DMNTableImpl <em>DMN Table</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.DMNTableImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getDMNTable()
	 * @generated
	 */
	int DMN_TABLE = 0;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN_TABLE__ELEMENTS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN_TABLE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Hitpolicie</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN_TABLE__HITPOLICIE = 2;

	/**
	 * The number of structural features of the '<em>DMN Table</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN_TABLE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>DMN Table</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN_TABLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.ElementsImpl <em>Elements</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.ElementsImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getElements()
	 * @generated
	 */
	int ELEMENTS = 1;

	/**
	 * The feature id for the '<em><b>Expression</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS__EXPRESSION = 0;

	/**
	 * The number of structural features of the '<em>Elements</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Elements</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.ClauseImpl <em>Clause</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.ClauseImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getClause()
	 * @generated
	 */
	int CLAUSE = 8;

	/**
	 * The feature id for the '<em><b>Expression</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLAUSE__EXPRESSION = ELEMENTS__EXPRESSION;

	/**
	 * The number of structural features of the '<em>Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLAUSE_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLAUSE_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.InputClauseImpl <em>Input Clause</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.InputClauseImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getInputClause()
	 * @generated
	 */
	int INPUT_CLAUSE = 2;

	/**
	 * The feature id for the '<em><b>Expression</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_CLAUSE__EXPRESSION = CLAUSE__EXPRESSION;

	/**
	 * The feature id for the '<em><b>Entries Input Clause</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE = CLAUSE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Input Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_CLAUSE_FEATURE_COUNT = CLAUSE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Input Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_CLAUSE_OPERATION_COUNT = CLAUSE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.OutputClauseImpl <em>Output Clause</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.OutputClauseImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getOutputClause()
	 * @generated
	 */
	int OUTPUT_CLAUSE = 3;

	/**
	 * The feature id for the '<em><b>Expression</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_CLAUSE__EXPRESSION = CLAUSE__EXPRESSION;

	/**
	 * The feature id for the '<em><b>Entries Output Clause</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE = CLAUSE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Output Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_CLAUSE_FEATURE_COUNT = CLAUSE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Output Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_CLAUSE_OPERATION_COUNT = CLAUSE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.RuleImpl <em>Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.RuleImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getRule()
	 * @generated
	 */
	int RULE = 4;

	/**
	 * The feature id for the '<em><b>Expression</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__EXPRESSION = ELEMENTS__EXPRESSION;

	/**
	 * The feature id for the '<em><b>Clause</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__CLAUSE = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Annotationclause</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__ANNOTATIONCLAUSE = ELEMENTS_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Hitpolicie</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__HITPOLICIE = ELEMENTS_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Entry</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__ENTRY = ELEMENTS_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.AnnotationClauseImpl <em>Annotation Clause</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.AnnotationClauseImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getAnnotationClause()
	 * @generated
	 */
	int ANNOTATION_CLAUSE = 5;

	/**
	 * The feature id for the '<em><b>Expression</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_CLAUSE__EXPRESSION = CLAUSE__EXPRESSION;

	/**
	 * The feature id for the '<em><b>Rule</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_CLAUSE__RULE = CLAUSE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Annotation Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_CLAUSE_FEATURE_COUNT = CLAUSE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Annotation Clause</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNOTATION_CLAUSE_OPERATION_COUNT = CLAUSE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.HitPolicieImpl <em>Hit Policie</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.HitPolicieImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getHitPolicie()
	 * @generated
	 */
	int HIT_POLICIE = 6;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIT_POLICIE__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Rule</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIT_POLICIE__RULE = 1;

	/**
	 * The number of structural features of the '<em>Hit Policie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIT_POLICIE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Hit Policie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIT_POLICIE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dMNTable.impl.EntryImpl <em>Entry</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.impl.EntryImpl
	 * @see dMNTable.impl.DMNTablePackageImpl#getEntry()
	 * @generated
	 */
	int ENTRY = 7;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Rule Assigned Entry</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY__RULE_ASSIGNED_ENTRY = 1;

	/**
	 * The number of structural features of the '<em>Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dMNTable.TypeHitPolicie <em>Type Hit Policie</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMNTable.TypeHitPolicie
	 * @see dMNTable.impl.DMNTablePackageImpl#getTypeHitPolicie()
	 * @generated
	 */
	int TYPE_HIT_POLICIE = 9;


	/**
	 * Returns the meta object for class '{@link dMNTable.DMNTable <em>DMN Table</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DMN Table</em>'.
	 * @see dMNTable.DMNTable
	 * @generated
	 */
	EClass getDMNTable();

	/**
	 * Returns the meta object for the containment reference list '{@link dMNTable.DMNTable#getElements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Elements</em>'.
	 * @see dMNTable.DMNTable#getElements()
	 * @see #getDMNTable()
	 * @generated
	 */
	EReference getDMNTable_Elements();

	/**
	 * Returns the meta object for the attribute '{@link dMNTable.DMNTable#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see dMNTable.DMNTable#getName()
	 * @see #getDMNTable()
	 * @generated
	 */
	EAttribute getDMNTable_Name();

	/**
	 * Returns the meta object for the containment reference '{@link dMNTable.DMNTable#getHitpolicie <em>Hitpolicie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Hitpolicie</em>'.
	 * @see dMNTable.DMNTable#getHitpolicie()
	 * @see #getDMNTable()
	 * @generated
	 */
	EReference getDMNTable_Hitpolicie();

	/**
	 * Returns the meta object for class '{@link dMNTable.Elements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elements</em>'.
	 * @see dMNTable.Elements
	 * @generated
	 */
	EClass getElements();

	/**
	 * Returns the meta object for the attribute '{@link dMNTable.Elements#getExpression <em>Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Expression</em>'.
	 * @see dMNTable.Elements#getExpression()
	 * @see #getElements()
	 * @generated
	 */
	EAttribute getElements_Expression();

	/**
	 * Returns the meta object for class '{@link dMNTable.InputClause <em>Input Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Clause</em>'.
	 * @see dMNTable.InputClause
	 * @generated
	 */
	EClass getInputClause();

	/**
	 * Returns the meta object for the containment reference list '{@link dMNTable.InputClause#getEntriesInputClause <em>Entries Input Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entries Input Clause</em>'.
	 * @see dMNTable.InputClause#getEntriesInputClause()
	 * @see #getInputClause()
	 * @generated
	 */
	EReference getInputClause_EntriesInputClause();

	/**
	 * Returns the meta object for class '{@link dMNTable.OutputClause <em>Output Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Output Clause</em>'.
	 * @see dMNTable.OutputClause
	 * @generated
	 */
	EClass getOutputClause();

	/**
	 * Returns the meta object for the containment reference list '{@link dMNTable.OutputClause#getEntriesOutputClause <em>Entries Output Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entries Output Clause</em>'.
	 * @see dMNTable.OutputClause#getEntriesOutputClause()
	 * @see #getOutputClause()
	 * @generated
	 */
	EReference getOutputClause_EntriesOutputClause();

	/**
	 * Returns the meta object for class '{@link dMNTable.Rule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rule</em>'.
	 * @see dMNTable.Rule
	 * @generated
	 */
	EClass getRule();

	/**
	 * Returns the meta object for the containment reference list '{@link dMNTable.Rule#getClause <em>Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Clause</em>'.
	 * @see dMNTable.Rule#getClause()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Clause();

	/**
	 * Returns the meta object for the reference list '{@link dMNTable.Rule#getAnnotationclause <em>Annotationclause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Annotationclause</em>'.
	 * @see dMNTable.Rule#getAnnotationclause()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Annotationclause();

	/**
	 * Returns the meta object for the reference '{@link dMNTable.Rule#getHitpolicie <em>Hitpolicie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Hitpolicie</em>'.
	 * @see dMNTable.Rule#getHitpolicie()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Hitpolicie();

	/**
	 * Returns the meta object for the reference list '{@link dMNTable.Rule#getEntry <em>Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Entry</em>'.
	 * @see dMNTable.Rule#getEntry()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Entry();

	/**
	 * Returns the meta object for class '{@link dMNTable.AnnotationClause <em>Annotation Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Annotation Clause</em>'.
	 * @see dMNTable.AnnotationClause
	 * @generated
	 */
	EClass getAnnotationClause();

	/**
	 * Returns the meta object for the reference '{@link dMNTable.AnnotationClause#getRule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rule</em>'.
	 * @see dMNTable.AnnotationClause#getRule()
	 * @see #getAnnotationClause()
	 * @generated
	 */
	EReference getAnnotationClause_Rule();

	/**
	 * Returns the meta object for class '{@link dMNTable.HitPolicie <em>Hit Policie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hit Policie</em>'.
	 * @see dMNTable.HitPolicie
	 * @generated
	 */
	EClass getHitPolicie();

	/**
	 * Returns the meta object for the attribute '{@link dMNTable.HitPolicie#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see dMNTable.HitPolicie#getType()
	 * @see #getHitPolicie()
	 * @generated
	 */
	EAttribute getHitPolicie_Type();

	/**
	 * Returns the meta object for the reference '{@link dMNTable.HitPolicie#getRule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rule</em>'.
	 * @see dMNTable.HitPolicie#getRule()
	 * @see #getHitPolicie()
	 * @generated
	 */
	EReference getHitPolicie_Rule();

	/**
	 * Returns the meta object for class '{@link dMNTable.Entry <em>Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entry</em>'.
	 * @see dMNTable.Entry
	 * @generated
	 */
	EClass getEntry();

	/**
	 * Returns the meta object for the attribute '{@link dMNTable.Entry#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see dMNTable.Entry#getValue()
	 * @see #getEntry()
	 * @generated
	 */
	EAttribute getEntry_Value();

	/**
	 * Returns the meta object for the reference '{@link dMNTable.Entry#getRuleAssignedEntry <em>Rule Assigned Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rule Assigned Entry</em>'.
	 * @see dMNTable.Entry#getRuleAssignedEntry()
	 * @see #getEntry()
	 * @generated
	 */
	EReference getEntry_RuleAssignedEntry();

	/**
	 * Returns the meta object for class '{@link dMNTable.Clause <em>Clause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Clause</em>'.
	 * @see dMNTable.Clause
	 * @generated
	 */
	EClass getClause();

	/**
	 * Returns the meta object for enum '{@link dMNTable.TypeHitPolicie <em>Type Hit Policie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type Hit Policie</em>'.
	 * @see dMNTable.TypeHitPolicie
	 * @generated
	 */
	EEnum getTypeHitPolicie();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DMNTableFactory getDMNTableFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link dMNTable.impl.DMNTableImpl <em>DMN Table</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.DMNTableImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getDMNTable()
		 * @generated
		 */
		EClass DMN_TABLE = eINSTANCE.getDMNTable();

		/**
		 * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DMN_TABLE__ELEMENTS = eINSTANCE.getDMNTable_Elements();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DMN_TABLE__NAME = eINSTANCE.getDMNTable_Name();

		/**
		 * The meta object literal for the '<em><b>Hitpolicie</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DMN_TABLE__HITPOLICIE = eINSTANCE.getDMNTable_Hitpolicie();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.ElementsImpl <em>Elements</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.ElementsImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getElements()
		 * @generated
		 */
		EClass ELEMENTS = eINSTANCE.getElements();

		/**
		 * The meta object literal for the '<em><b>Expression</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENTS__EXPRESSION = eINSTANCE.getElements_Expression();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.InputClauseImpl <em>Input Clause</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.InputClauseImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getInputClause()
		 * @generated
		 */
		EClass INPUT_CLAUSE = eINSTANCE.getInputClause();

		/**
		 * The meta object literal for the '<em><b>Entries Input Clause</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_CLAUSE__ENTRIES_INPUT_CLAUSE = eINSTANCE.getInputClause_EntriesInputClause();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.OutputClauseImpl <em>Output Clause</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.OutputClauseImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getOutputClause()
		 * @generated
		 */
		EClass OUTPUT_CLAUSE = eINSTANCE.getOutputClause();

		/**
		 * The meta object literal for the '<em><b>Entries Output Clause</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OUTPUT_CLAUSE__ENTRIES_OUTPUT_CLAUSE = eINSTANCE.getOutputClause_EntriesOutputClause();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.RuleImpl <em>Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.RuleImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getRule()
		 * @generated
		 */
		EClass RULE = eINSTANCE.getRule();

		/**
		 * The meta object literal for the '<em><b>Clause</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__CLAUSE = eINSTANCE.getRule_Clause();

		/**
		 * The meta object literal for the '<em><b>Annotationclause</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__ANNOTATIONCLAUSE = eINSTANCE.getRule_Annotationclause();

		/**
		 * The meta object literal for the '<em><b>Hitpolicie</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__HITPOLICIE = eINSTANCE.getRule_Hitpolicie();

		/**
		 * The meta object literal for the '<em><b>Entry</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__ENTRY = eINSTANCE.getRule_Entry();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.AnnotationClauseImpl <em>Annotation Clause</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.AnnotationClauseImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getAnnotationClause()
		 * @generated
		 */
		EClass ANNOTATION_CLAUSE = eINSTANCE.getAnnotationClause();

		/**
		 * The meta object literal for the '<em><b>Rule</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANNOTATION_CLAUSE__RULE = eINSTANCE.getAnnotationClause_Rule();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.HitPolicieImpl <em>Hit Policie</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.HitPolicieImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getHitPolicie()
		 * @generated
		 */
		EClass HIT_POLICIE = eINSTANCE.getHitPolicie();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HIT_POLICIE__TYPE = eINSTANCE.getHitPolicie_Type();

		/**
		 * The meta object literal for the '<em><b>Rule</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HIT_POLICIE__RULE = eINSTANCE.getHitPolicie_Rule();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.EntryImpl <em>Entry</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.EntryImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getEntry()
		 * @generated
		 */
		EClass ENTRY = eINSTANCE.getEntry();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTRY__VALUE = eINSTANCE.getEntry_Value();

		/**
		 * The meta object literal for the '<em><b>Rule Assigned Entry</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTRY__RULE_ASSIGNED_ENTRY = eINSTANCE.getEntry_RuleAssignedEntry();

		/**
		 * The meta object literal for the '{@link dMNTable.impl.ClauseImpl <em>Clause</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.impl.ClauseImpl
		 * @see dMNTable.impl.DMNTablePackageImpl#getClause()
		 * @generated
		 */
		EClass CLAUSE = eINSTANCE.getClause();

		/**
		 * The meta object literal for the '{@link dMNTable.TypeHitPolicie <em>Type Hit Policie</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMNTable.TypeHitPolicie
		 * @see dMNTable.impl.DMNTablePackageImpl#getTypeHitPolicie()
		 * @generated
		 */
		EEnum TYPE_HIT_POLICIE = eINSTANCE.getTypeHitPolicie();

	}

} //DMNTablePackage
