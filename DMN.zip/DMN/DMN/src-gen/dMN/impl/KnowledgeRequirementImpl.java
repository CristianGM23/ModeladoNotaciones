/**
 */
package dMN.impl;

import dMN.DMNPackage;
import dMN.KnowledgeRequirement;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Knowledge Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class KnowledgeRequirementImpl extends ConnectorsImpl implements KnowledgeRequirement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected KnowledgeRequirementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNPackage.Literals.KNOWLEDGE_REQUIREMENT;
	}

} //KnowledgeRequirementImpl
