/**
 */
package dMN.impl;

import dMN.AuthorityRequirement;
import dMN.DMNPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Authority Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AuthorityRequirementImpl extends ConnectorsImpl implements AuthorityRequirement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AuthorityRequirementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNPackage.Literals.AUTHORITY_REQUIREMENT;
	}

} //AuthorityRequirementImpl
