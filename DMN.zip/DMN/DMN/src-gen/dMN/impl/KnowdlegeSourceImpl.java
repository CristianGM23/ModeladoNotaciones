/**
 */
package dMN.impl;

import dMN.DMNPackage;
import dMN.KnowdlegeSource;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Knowdlege Source</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class KnowdlegeSourceImpl extends ElementsImpl implements KnowdlegeSource {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected KnowdlegeSourceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNPackage.Literals.KNOWDLEGE_SOURCE;
	}

} //KnowdlegeSourceImpl
