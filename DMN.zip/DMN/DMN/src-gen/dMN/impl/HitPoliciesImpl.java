/**
 */
package dMN.impl;

import dMN.DMNPackage;
import dMN.HitPolicies;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hit Policies</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class HitPoliciesImpl extends ElementsImpl implements HitPolicies {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HitPoliciesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNPackage.Literals.HIT_POLICIES;
	}

} //HitPoliciesImpl
