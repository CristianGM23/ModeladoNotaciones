/**
 */
package dMN.impl;

import dMN.Association;
import dMN.AuthorityRequirement;
import dMN.BusinessKnowledge;
import dMN.Connectors;
import dMN.DMNFactory;
import dMN.DMNPackage;
import dMN.Decision;
import dMN.DecisionService;
import dMN.Elements;
import dMN.HitPolicies;
import dMN.IndividualResults;
import dMN.InformationRequirement;
import dMN.InputData;
import dMN.KnowdlegeSource;
import dMN.KnowledgeRequirement;
import dMN.SeveralResults;
import dMN.TextAnnotation;
import dMN.TypeHitPoliciesIndividualResults;
import dMN.TypeHitPoliciesSeveralResults;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DMNPackageImpl extends EPackageImpl implements DMNPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dmnEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass businessKnowledgeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inputDataEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decisionServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass knowdlegeSourceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elementsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connectorsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass knowledgeRequirementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass informationRequirementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass authorityRequirementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hitPoliciesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass individualResultsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass severalResultsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decisionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass textAnnotationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum typeHitPoliciesIndividualResultsEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum typeHitPoliciesSeveralResultsEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see dMN.DMNPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DMNPackageImpl() {
		super(eNS_URI, DMNFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link DMNPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DMNPackage init() {
		if (isInited)
			return (DMNPackage) EPackage.Registry.INSTANCE.getEPackage(DMNPackage.eNS_URI);

		// Obtain or create and register package
		DMNPackageImpl theDMNPackage = (DMNPackageImpl) (EPackage.Registry.INSTANCE
				.get(eNS_URI) instanceof DMNPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI)
						: new DMNPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theDMNPackage.createPackageContents();

		// Initialize created meta-data
		theDMNPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDMNPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(DMNPackage.eNS_URI, theDMNPackage);
		return theDMNPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDMN() {
		return dmnEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDMN_Elements() {
		return (EReference) dmnEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDMN_Name() {
		return (EAttribute) dmnEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBusinessKnowledge() {
		return businessKnowledgeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInputData() {
		return inputDataEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInputData_Decision() {
		return (EReference) inputDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDecisionService() {
		return decisionServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDecisionService_Decision() {
		return (EReference) decisionServiceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getKnowdlegeSource() {
		return knowdlegeSourceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElements() {
		return elementsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElements_ConnectionTarget() {
		return (EReference) elementsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElements_ConnectionSource() {
		return (EReference) elementsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getElements_Name() {
		return (EAttribute) elementsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConnectors() {
		return connectorsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConnectors_To() {
		return (EReference) connectorsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConnectors_From() {
		return (EReference) connectorsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getKnowledgeRequirement() {
		return knowledgeRequirementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInformationRequirement() {
		return informationRequirementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAuthorityRequirement() {
		return authorityRequirementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHitPolicies() {
		return hitPoliciesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIndividualResults() {
		return individualResultsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIndividualResults_Type() {
		return (EAttribute) individualResultsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSeveralResults() {
		return severalResultsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSeveralResults_Type() {
		return (EAttribute) severalResultsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDecision() {
		return decisionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDecision_InputDataDecision() {
		return (EReference) decisionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTextAnnotation() {
		return textAnnotationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociation() {
		return associationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTypeHitPoliciesIndividualResults() {
		return typeHitPoliciesIndividualResultsEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTypeHitPoliciesSeveralResults() {
		return typeHitPoliciesSeveralResultsEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNFactory getDMNFactory() {
		return (DMNFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		dmnEClass = createEClass(DMN);
		createEReference(dmnEClass, DMN__ELEMENTS);
		createEAttribute(dmnEClass, DMN__NAME);

		businessKnowledgeEClass = createEClass(BUSINESS_KNOWLEDGE);

		inputDataEClass = createEClass(INPUT_DATA);
		createEReference(inputDataEClass, INPUT_DATA__DECISION);

		decisionServiceEClass = createEClass(DECISION_SERVICE);
		createEReference(decisionServiceEClass, DECISION_SERVICE__DECISION);

		knowdlegeSourceEClass = createEClass(KNOWDLEGE_SOURCE);

		elementsEClass = createEClass(ELEMENTS);
		createEReference(elementsEClass, ELEMENTS__CONNECTION_TARGET);
		createEReference(elementsEClass, ELEMENTS__CONNECTION_SOURCE);
		createEAttribute(elementsEClass, ELEMENTS__NAME);

		connectorsEClass = createEClass(CONNECTORS);
		createEReference(connectorsEClass, CONNECTORS__TO);
		createEReference(connectorsEClass, CONNECTORS__FROM);

		knowledgeRequirementEClass = createEClass(KNOWLEDGE_REQUIREMENT);

		informationRequirementEClass = createEClass(INFORMATION_REQUIREMENT);

		authorityRequirementEClass = createEClass(AUTHORITY_REQUIREMENT);

		hitPoliciesEClass = createEClass(HIT_POLICIES);

		individualResultsEClass = createEClass(INDIVIDUAL_RESULTS);
		createEAttribute(individualResultsEClass, INDIVIDUAL_RESULTS__TYPE);

		severalResultsEClass = createEClass(SEVERAL_RESULTS);
		createEAttribute(severalResultsEClass, SEVERAL_RESULTS__TYPE);

		decisionEClass = createEClass(DECISION);
		createEReference(decisionEClass, DECISION__INPUT_DATA_DECISION);

		textAnnotationEClass = createEClass(TEXT_ANNOTATION);

		associationEClass = createEClass(ASSOCIATION);

		// Create enums
		typeHitPoliciesIndividualResultsEEnum = createEEnum(TYPE_HIT_POLICIES_INDIVIDUAL_RESULTS);
		typeHitPoliciesSeveralResultsEEnum = createEEnum(TYPE_HIT_POLICIES_SEVERAL_RESULTS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		businessKnowledgeEClass.getESuperTypes().add(this.getElements());
		inputDataEClass.getESuperTypes().add(this.getElements());
		decisionServiceEClass.getESuperTypes().add(this.getElements());
		knowdlegeSourceEClass.getESuperTypes().add(this.getElements());
		knowledgeRequirementEClass.getESuperTypes().add(this.getConnectors());
		informationRequirementEClass.getESuperTypes().add(this.getConnectors());
		authorityRequirementEClass.getESuperTypes().add(this.getConnectors());
		hitPoliciesEClass.getESuperTypes().add(this.getElements());
		individualResultsEClass.getESuperTypes().add(this.getHitPolicies());
		severalResultsEClass.getESuperTypes().add(this.getHitPolicies());
		textAnnotationEClass.getESuperTypes().add(this.getElements());
		associationEClass.getESuperTypes().add(this.getConnectors());

		// Initialize classes, features, and operations; add parameters
		initEClass(dmnEClass, dMN.DMN.class, "DMN", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDMN_Elements(), this.getElements(), null, "elements", null, 0, -1, dMN.DMN.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDMN_Name(), ecorePackage.getEString(), "name", null, 0, 1, dMN.DMN.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(businessKnowledgeEClass, BusinessKnowledge.class, "BusinessKnowledge", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(inputDataEClass, InputData.class, "InputData", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInputData_Decision(), this.getDecision(), this.getDecision_InputDataDecision(), "decision",
				null, 1, 1, InputData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(decisionServiceEClass, DecisionService.class, "DecisionService", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDecisionService_Decision(), this.getDecision(), null, "decision", null, 1, -1,
				DecisionService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(knowdlegeSourceEClass, KnowdlegeSource.class, "KnowdlegeSource", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(elementsEClass, Elements.class, "Elements", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getElements_ConnectionTarget(), this.getConnectors(), this.getConnectors_To(),
				"connectionTarget", null, 0, -1, Elements.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getElements_ConnectionSource(), this.getConnectors(), this.getConnectors_From(),
				"connectionSource", null, 0, -1, Elements.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getElements_Name(), ecorePackage.getEString(), "name", null, 0, 1, Elements.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(connectorsEClass, Connectors.class, "Connectors", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConnectors_To(), this.getElements(), this.getElements_ConnectionTarget(), "to", null, 1, 1,
				Connectors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConnectors_From(), this.getElements(), this.getElements_ConnectionSource(), "from", null, 1,
				1, Connectors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(knowledgeRequirementEClass, KnowledgeRequirement.class, "KnowledgeRequirement", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(informationRequirementEClass, InformationRequirement.class, "InformationRequirement", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(authorityRequirementEClass, AuthorityRequirement.class, "AuthorityRequirement", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(hitPoliciesEClass, HitPolicies.class, "HitPolicies", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(individualResultsEClass, IndividualResults.class, "IndividualResults", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIndividualResults_Type(), this.getTypeHitPoliciesIndividualResults(), "type", null, 0, 1,
				IndividualResults.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(severalResultsEClass, SeveralResults.class, "SeveralResults", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSeveralResults_Type(), this.getTypeHitPoliciesSeveralResults(), "type", null, 0, 1,
				SeveralResults.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(decisionEClass, Decision.class, "Decision", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDecision_InputDataDecision(), this.getInputData(), this.getInputData_Decision(),
				"inputDataDecision", null, 1, -1, Decision.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(textAnnotationEClass, TextAnnotation.class, "TextAnnotation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(associationEClass, Association.class, "Association", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(typeHitPoliciesIndividualResultsEEnum, TypeHitPoliciesIndividualResults.class,
				"TypeHitPoliciesIndividualResults");
		addEEnumLiteral(typeHitPoliciesIndividualResultsEEnum, TypeHitPoliciesIndividualResults.UNIQUE);
		addEEnumLiteral(typeHitPoliciesIndividualResultsEEnum, TypeHitPoliciesIndividualResults.ANY);
		addEEnumLiteral(typeHitPoliciesIndividualResultsEEnum, TypeHitPoliciesIndividualResults.PRIORITY);
		addEEnumLiteral(typeHitPoliciesIndividualResultsEEnum, TypeHitPoliciesIndividualResults.FIRST);

		initEEnum(typeHitPoliciesSeveralResultsEEnum, TypeHitPoliciesSeveralResults.class,
				"TypeHitPoliciesSeveralResults");
		addEEnumLiteral(typeHitPoliciesSeveralResultsEEnum, TypeHitPoliciesSeveralResults.OUTPUT_ORDER);
		addEEnumLiteral(typeHitPoliciesSeveralResultsEEnum, TypeHitPoliciesSeveralResults.RULE_ORDER);
		addEEnumLiteral(typeHitPoliciesSeveralResultsEEnum, TypeHitPoliciesSeveralResults.COLLECT);

		// Create resource
		createResource(eNS_URI);
	}

} //DMNPackageImpl
