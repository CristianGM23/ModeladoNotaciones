/**
 */
package dMN.impl;

import dMN.BusinessKnowledge;
import dMN.DMNPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Business Knowledge</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BusinessKnowledgeImpl extends ElementsImpl implements BusinessKnowledge {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BusinessKnowledgeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNPackage.Literals.BUSINESS_KNOWLEDGE;
	}

} //BusinessKnowledgeImpl
