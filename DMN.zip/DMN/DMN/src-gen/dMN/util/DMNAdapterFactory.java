/**
 */
package dMN.util;

import dMN.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see dMN.DMNPackage
 * @generated
 */
public class DMNAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static DMNPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = DMNPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DMNSwitch<Adapter> modelSwitch = new DMNSwitch<Adapter>() {
		@Override
		public Adapter caseDMN(DMN object) {
			return createDMNAdapter();
		}

		@Override
		public Adapter caseBusinessKnowledge(BusinessKnowledge object) {
			return createBusinessKnowledgeAdapter();
		}

		@Override
		public Adapter caseInputData(InputData object) {
			return createInputDataAdapter();
		}

		@Override
		public Adapter caseDecisionService(DecisionService object) {
			return createDecisionServiceAdapter();
		}

		@Override
		public Adapter caseKnowdlegeSource(KnowdlegeSource object) {
			return createKnowdlegeSourceAdapter();
		}

		@Override
		public Adapter caseElements(Elements object) {
			return createElementsAdapter();
		}

		@Override
		public Adapter caseConnectors(Connectors object) {
			return createConnectorsAdapter();
		}

		@Override
		public Adapter caseKnowledgeRequirement(KnowledgeRequirement object) {
			return createKnowledgeRequirementAdapter();
		}

		@Override
		public Adapter caseInformationRequirement(InformationRequirement object) {
			return createInformationRequirementAdapter();
		}

		@Override
		public Adapter caseAuthorityRequirement(AuthorityRequirement object) {
			return createAuthorityRequirementAdapter();
		}

		@Override
		public Adapter caseHitPolicies(HitPolicies object) {
			return createHitPoliciesAdapter();
		}

		@Override
		public Adapter caseIndividualResults(IndividualResults object) {
			return createIndividualResultsAdapter();
		}

		@Override
		public Adapter caseSeveralResults(SeveralResults object) {
			return createSeveralResultsAdapter();
		}

		@Override
		public Adapter caseDecision(Decision object) {
			return createDecisionAdapter();
		}

		@Override
		public Adapter caseTextAnnotation(TextAnnotation object) {
			return createTextAnnotationAdapter();
		}

		@Override
		public Adapter caseAssociation(Association object) {
			return createAssociationAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.DMN <em>DMN</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.DMN
	 * @generated
	 */
	public Adapter createDMNAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.BusinessKnowledge <em>Business Knowledge</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.BusinessKnowledge
	 * @generated
	 */
	public Adapter createBusinessKnowledgeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.InputData <em>Input Data</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.InputData
	 * @generated
	 */
	public Adapter createInputDataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.DecisionService <em>Decision Service</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.DecisionService
	 * @generated
	 */
	public Adapter createDecisionServiceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.KnowdlegeSource <em>Knowdlege Source</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.KnowdlegeSource
	 * @generated
	 */
	public Adapter createKnowdlegeSourceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.Elements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.Elements
	 * @generated
	 */
	public Adapter createElementsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.Connectors <em>Connectors</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.Connectors
	 * @generated
	 */
	public Adapter createConnectorsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.KnowledgeRequirement <em>Knowledge Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.KnowledgeRequirement
	 * @generated
	 */
	public Adapter createKnowledgeRequirementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.InformationRequirement <em>Information Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.InformationRequirement
	 * @generated
	 */
	public Adapter createInformationRequirementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.AuthorityRequirement <em>Authority Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.AuthorityRequirement
	 * @generated
	 */
	public Adapter createAuthorityRequirementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.HitPolicies <em>Hit Policies</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.HitPolicies
	 * @generated
	 */
	public Adapter createHitPoliciesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.IndividualResults <em>Individual Results</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.IndividualResults
	 * @generated
	 */
	public Adapter createIndividualResultsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.SeveralResults <em>Several Results</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.SeveralResults
	 * @generated
	 */
	public Adapter createSeveralResultsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.Decision <em>Decision</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.Decision
	 * @generated
	 */
	public Adapter createDecisionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.TextAnnotation <em>Text Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.TextAnnotation
	 * @generated
	 */
	public Adapter createTextAnnotationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dMN.Association <em>Association</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dMN.Association
	 * @generated
	 */
	public Adapter createAssociationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //DMNAdapterFactory
