/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Text Annotation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getTextAnnotation()
 * @model
 * @generated
 */
public interface TextAnnotation extends Elements {
} // TextAnnotation
