/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Several Results</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.SeveralResults#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getSeveralResults()
 * @model
 * @generated
 */
public interface SeveralResults extends HitPolicies {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link dMN.TypeHitPoliciesSeveralResults}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see dMN.TypeHitPoliciesSeveralResults
	 * @see #setType(TypeHitPoliciesSeveralResults)
	 * @see dMN.DMNPackage#getSeveralResults_Type()
	 * @model
	 * @generated
	 */
	TypeHitPoliciesSeveralResults getType();

	/**
	 * Sets the value of the '{@link dMN.SeveralResults#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see dMN.TypeHitPoliciesSeveralResults
	 * @see #getType()
	 * @generated
	 */
	void setType(TypeHitPoliciesSeveralResults value);

} // SeveralResults
