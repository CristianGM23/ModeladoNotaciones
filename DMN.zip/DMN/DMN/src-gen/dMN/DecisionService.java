/**
 */
package dMN;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decision Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.DecisionService#getDecision <em>Decision</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getDecisionService()
 * @model
 * @generated
 */
public interface DecisionService extends Elements {
	/**
	 * Returns the value of the '<em><b>Decision</b></em>' containment reference list.
	 * The list contents are of type {@link dMN.Decision}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Decision</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Decision</em>' containment reference list.
	 * @see dMN.DMNPackage#getDecisionService_Decision()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Decision> getDecision();

} // DecisionService
