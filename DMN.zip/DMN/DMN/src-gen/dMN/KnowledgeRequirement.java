/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Knowledge Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getKnowledgeRequirement()
 * @model
 * @generated
 */
public interface KnowledgeRequirement extends Connectors {
} // KnowledgeRequirement
