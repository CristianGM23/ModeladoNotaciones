/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Business Knowledge</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getBusinessKnowledge()
 * @model
 * @generated
 */
public interface BusinessKnowledge extends Elements {
} // BusinessKnowledge
