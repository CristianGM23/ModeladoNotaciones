/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.InputData#getDecision <em>Decision</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getInputData()
 * @model
 * @generated
 */
public interface InputData extends Elements {
	/**
	 * Returns the value of the '<em><b>Decision</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link dMN.Decision#getInputDataDecision <em>Input Data Decision</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Decision</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Decision</em>' reference.
	 * @see #setDecision(Decision)
	 * @see dMN.DMNPackage#getInputData_Decision()
	 * @see dMN.Decision#getInputDataDecision
	 * @model opposite="inputDataDecision" required="true"
	 * @generated
	 */
	Decision getDecision();

	/**
	 * Sets the value of the '{@link dMN.InputData#getDecision <em>Decision</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Decision</em>' reference.
	 * @see #getDecision()
	 * @generated
	 */
	void setDecision(Decision value);

} // InputData
