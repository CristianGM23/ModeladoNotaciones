/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Authority Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getAuthorityRequirement()
 * @model
 * @generated
 */
public interface AuthorityRequirement extends Connectors {
} // AuthorityRequirement
