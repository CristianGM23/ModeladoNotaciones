/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Association</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getAssociation()
 * @model
 * @generated
 */
public interface Association extends Connectors {
} // Association
