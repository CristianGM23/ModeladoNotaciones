/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Knowdlege Source</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getKnowdlegeSource()
 * @model
 * @generated
 */
public interface KnowdlegeSource extends Elements {
} // KnowdlegeSource
