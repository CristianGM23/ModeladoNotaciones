/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Individual Results</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.IndividualResults#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getIndividualResults()
 * @model
 * @generated
 */
public interface IndividualResults extends HitPolicies {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link dMN.TypeHitPoliciesIndividualResults}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see dMN.TypeHitPoliciesIndividualResults
	 * @see #setType(TypeHitPoliciesIndividualResults)
	 * @see dMN.DMNPackage#getIndividualResults_Type()
	 * @model
	 * @generated
	 */
	TypeHitPoliciesIndividualResults getType();

	/**
	 * Sets the value of the '{@link dMN.IndividualResults#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see dMN.TypeHitPoliciesIndividualResults
	 * @see #getType()
	 * @generated
	 */
	void setType(TypeHitPoliciesIndividualResults value);

} // IndividualResults
