/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Information Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getInformationRequirement()
 * @model
 * @generated
 */
public interface InformationRequirement extends Connectors {
} // InformationRequirement
