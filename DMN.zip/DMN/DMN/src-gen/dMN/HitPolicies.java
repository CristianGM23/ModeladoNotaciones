/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hit Policies</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dMN.DMNPackage#getHitPolicies()
 * @model abstract="true"
 * @generated
 */
public interface HitPolicies extends Elements {
} // HitPolicies
