/**
 */
package dMN;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connectors</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.Connectors#getTo <em>To</em>}</li>
 *   <li>{@link dMN.Connectors#getFrom <em>From</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getConnectors()
 * @model
 * @generated
 */
public interface Connectors extends EObject {
	/**
	 * Returns the value of the '<em><b>To</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link dMN.Elements#getConnectionTarget <em>Connection Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To</em>' reference.
	 * @see #setTo(Elements)
	 * @see dMN.DMNPackage#getConnectors_To()
	 * @see dMN.Elements#getConnectionTarget
	 * @model opposite="connectionTarget" required="true"
	 * @generated
	 */
	Elements getTo();

	/**
	 * Sets the value of the '{@link dMN.Connectors#getTo <em>To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To</em>' reference.
	 * @see #getTo()
	 * @generated
	 */
	void setTo(Elements value);

	/**
	 * Returns the value of the '<em><b>From</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link dMN.Elements#getConnectionSource <em>Connection Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From</em>' reference.
	 * @see #setFrom(Elements)
	 * @see dMN.DMNPackage#getConnectors_From()
	 * @see dMN.Elements#getConnectionSource
	 * @model opposite="connectionSource" required="true"
	 * @generated
	 */
	Elements getFrom();

	/**
	 * Sets the value of the '{@link dMN.Connectors#getFrom <em>From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>From</em>' reference.
	 * @see #getFrom()
	 * @generated
	 */
	void setFrom(Elements value);

} // Connectors
