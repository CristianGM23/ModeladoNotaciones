/**
 */
package dMN;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see dMN.DMNFactory
 * @model kind="package"
 * @generated
 */
public interface DMNPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "dMN";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/dMN";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "dMN";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DMNPackage eINSTANCE = dMN.impl.DMNPackageImpl.init();

	/**
	 * The meta object id for the '{@link dMN.impl.DMNImpl <em>DMN</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.DMNImpl
	 * @see dMN.impl.DMNPackageImpl#getDMN()
	 * @generated
	 */
	int DMN = 0;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN__ELEMENTS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN__NAME = 1;

	/**
	 * The number of structural features of the '<em>DMN</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>DMN</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DMN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dMN.impl.ElementsImpl <em>Elements</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.ElementsImpl
	 * @see dMN.impl.DMNPackageImpl#getElements()
	 * @generated
	 */
	int ELEMENTS = 5;

	/**
	 * The feature id for the '<em><b>Connection Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS__CONNECTION_TARGET = 0;

	/**
	 * The feature id for the '<em><b>Connection Source</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS__CONNECTION_SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS__NAME = 2;

	/**
	 * The feature id for the '<em><b>Connectors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS__CONNECTORS = 3;

	/**
	 * The number of structural features of the '<em>Elements</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Elements</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENTS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dMN.impl.BusinessKnowledgeImpl <em>Business Knowledge</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.BusinessKnowledgeImpl
	 * @see dMN.impl.DMNPackageImpl#getBusinessKnowledge()
	 * @generated
	 */
	int BUSINESS_KNOWLEDGE = 1;

	/**
	 * The feature id for the '<em><b>Connection Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUSINESS_KNOWLEDGE__CONNECTION_TARGET = ELEMENTS__CONNECTION_TARGET;

	/**
	 * The feature id for the '<em><b>Connection Source</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUSINESS_KNOWLEDGE__CONNECTION_SOURCE = ELEMENTS__CONNECTION_SOURCE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUSINESS_KNOWLEDGE__NAME = ELEMENTS__NAME;

	/**
	 * The feature id for the '<em><b>Connectors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUSINESS_KNOWLEDGE__CONNECTORS = ELEMENTS__CONNECTORS;

	/**
	 * The number of structural features of the '<em>Business Knowledge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUSINESS_KNOWLEDGE_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Business Knowledge</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUSINESS_KNOWLEDGE_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.InputDataImpl <em>Input Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.InputDataImpl
	 * @see dMN.impl.DMNPackageImpl#getInputData()
	 * @generated
	 */
	int INPUT_DATA = 2;

	/**
	 * The feature id for the '<em><b>Connection Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DATA__CONNECTION_TARGET = ELEMENTS__CONNECTION_TARGET;

	/**
	 * The feature id for the '<em><b>Connection Source</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DATA__CONNECTION_SOURCE = ELEMENTS__CONNECTION_SOURCE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DATA__NAME = ELEMENTS__NAME;

	/**
	 * The feature id for the '<em><b>Connectors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DATA__CONNECTORS = ELEMENTS__CONNECTORS;

	/**
	 * The feature id for the '<em><b>Decision</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DATA__DECISION = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Input Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DATA_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Input Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_DATA_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.DecisionServiceImpl <em>Decision Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.DecisionServiceImpl
	 * @see dMN.impl.DMNPackageImpl#getDecisionService()
	 * @generated
	 */
	int DECISION_SERVICE = 3;

	/**
	 * The feature id for the '<em><b>Connection Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_SERVICE__CONNECTION_TARGET = ELEMENTS__CONNECTION_TARGET;

	/**
	 * The feature id for the '<em><b>Connection Source</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_SERVICE__CONNECTION_SOURCE = ELEMENTS__CONNECTION_SOURCE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_SERVICE__NAME = ELEMENTS__NAME;

	/**
	 * The feature id for the '<em><b>Connectors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_SERVICE__CONNECTORS = ELEMENTS__CONNECTORS;

	/**
	 * The feature id for the '<em><b>Decision</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_SERVICE__DECISION = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Decision Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_SERVICE_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Decision Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_SERVICE_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.KnowdlegeSourceImpl <em>Knowdlege Source</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.KnowdlegeSourceImpl
	 * @see dMN.impl.DMNPackageImpl#getKnowdlegeSource()
	 * @generated
	 */
	int KNOWDLEGE_SOURCE = 4;

	/**
	 * The feature id for the '<em><b>Connection Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWDLEGE_SOURCE__CONNECTION_TARGET = ELEMENTS__CONNECTION_TARGET;

	/**
	 * The feature id for the '<em><b>Connection Source</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWDLEGE_SOURCE__CONNECTION_SOURCE = ELEMENTS__CONNECTION_SOURCE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWDLEGE_SOURCE__NAME = ELEMENTS__NAME;

	/**
	 * The feature id for the '<em><b>Connectors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWDLEGE_SOURCE__CONNECTORS = ELEMENTS__CONNECTORS;

	/**
	 * The number of structural features of the '<em>Knowdlege Source</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWDLEGE_SOURCE_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Knowdlege Source</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWDLEGE_SOURCE_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.ConnectorsImpl <em>Connectors</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.ConnectorsImpl
	 * @see dMN.impl.DMNPackageImpl#getConnectors()
	 * @generated
	 */
	int CONNECTORS = 6;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTORS__TO = 0;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTORS__FROM = 1;

	/**
	 * The number of structural features of the '<em>Connectors</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTORS_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Connectors</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTORS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dMN.impl.KnowledgeRequirementImpl <em>Knowledge Requirement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.KnowledgeRequirementImpl
	 * @see dMN.impl.DMNPackageImpl#getKnowledgeRequirement()
	 * @generated
	 */
	int KNOWLEDGE_REQUIREMENT = 7;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWLEDGE_REQUIREMENT__TO = CONNECTORS__TO;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWLEDGE_REQUIREMENT__FROM = CONNECTORS__FROM;

	/**
	 * The number of structural features of the '<em>Knowledge Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWLEDGE_REQUIREMENT_FEATURE_COUNT = CONNECTORS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Knowledge Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KNOWLEDGE_REQUIREMENT_OPERATION_COUNT = CONNECTORS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.InformationRequirementImpl <em>Information Requirement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.InformationRequirementImpl
	 * @see dMN.impl.DMNPackageImpl#getInformationRequirement()
	 * @generated
	 */
	int INFORMATION_REQUIREMENT = 8;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_REQUIREMENT__TO = CONNECTORS__TO;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_REQUIREMENT__FROM = CONNECTORS__FROM;

	/**
	 * The number of structural features of the '<em>Information Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_REQUIREMENT_FEATURE_COUNT = CONNECTORS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Information Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_REQUIREMENT_OPERATION_COUNT = CONNECTORS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.AuthorityRequirementImpl <em>Authority Requirement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.AuthorityRequirementImpl
	 * @see dMN.impl.DMNPackageImpl#getAuthorityRequirement()
	 * @generated
	 */
	int AUTHORITY_REQUIREMENT = 9;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORITY_REQUIREMENT__TO = CONNECTORS__TO;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORITY_REQUIREMENT__FROM = CONNECTORS__FROM;

	/**
	 * The number of structural features of the '<em>Authority Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORITY_REQUIREMENT_FEATURE_COUNT = CONNECTORS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Authority Requirement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORITY_REQUIREMENT_OPERATION_COUNT = CONNECTORS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.DecisionImpl <em>Decision</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.DecisionImpl
	 * @see dMN.impl.DMNPackageImpl#getDecision()
	 * @generated
	 */
	int DECISION = 10;

	/**
	 * The feature id for the '<em><b>Connection Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION__CONNECTION_TARGET = ELEMENTS__CONNECTION_TARGET;

	/**
	 * The feature id for the '<em><b>Connection Source</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION__CONNECTION_SOURCE = ELEMENTS__CONNECTION_SOURCE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION__NAME = ELEMENTS__NAME;

	/**
	 * The feature id for the '<em><b>Connectors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION__CONNECTORS = ELEMENTS__CONNECTORS;

	/**
	 * The feature id for the '<em><b>Input Data Decision</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION__INPUT_DATA_DECISION = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Decision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Decision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.TextAnnotationImpl <em>Text Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.TextAnnotationImpl
	 * @see dMN.impl.DMNPackageImpl#getTextAnnotation()
	 * @generated
	 */
	int TEXT_ANNOTATION = 11;

	/**
	 * The feature id for the '<em><b>Connection Target</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_ANNOTATION__CONNECTION_TARGET = ELEMENTS__CONNECTION_TARGET;

	/**
	 * The feature id for the '<em><b>Connection Source</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_ANNOTATION__CONNECTION_SOURCE = ELEMENTS__CONNECTION_SOURCE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_ANNOTATION__NAME = ELEMENTS__NAME;

	/**
	 * The feature id for the '<em><b>Connectors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_ANNOTATION__CONNECTORS = ELEMENTS__CONNECTORS;

	/**
	 * The number of structural features of the '<em>Text Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_ANNOTATION_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Text Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_ANNOTATION_OPERATION_COUNT = ELEMENTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.impl.AssociationImpl <em>Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.impl.AssociationImpl
	 * @see dMN.impl.DMNPackageImpl#getAssociation()
	 * @generated
	 */
	int ASSOCIATION = 12;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__TO = CONNECTORS__TO;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__FROM = CONNECTORS__FROM;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__TYPE = CONNECTORS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_FEATURE_COUNT = CONNECTORS_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_OPERATION_COUNT = CONNECTORS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dMN.typeAssociation <em>type Association</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dMN.typeAssociation
	 * @see dMN.impl.DMNPackageImpl#gettypeAssociation()
	 * @generated
	 */
	int TYPE_ASSOCIATION = 13;

	/**
	 * Returns the meta object for class '{@link dMN.DMN <em>DMN</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DMN</em>'.
	 * @see dMN.DMN
	 * @generated
	 */
	EClass getDMN();

	/**
	 * Returns the meta object for the containment reference list '{@link dMN.DMN#getElements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Elements</em>'.
	 * @see dMN.DMN#getElements()
	 * @see #getDMN()
	 * @generated
	 */
	EReference getDMN_Elements();

	/**
	 * Returns the meta object for the attribute '{@link dMN.DMN#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see dMN.DMN#getName()
	 * @see #getDMN()
	 * @generated
	 */
	EAttribute getDMN_Name();

	/**
	 * Returns the meta object for class '{@link dMN.BusinessKnowledge <em>Business Knowledge</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Business Knowledge</em>'.
	 * @see dMN.BusinessKnowledge
	 * @generated
	 */
	EClass getBusinessKnowledge();

	/**
	 * Returns the meta object for class '{@link dMN.InputData <em>Input Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Data</em>'.
	 * @see dMN.InputData
	 * @generated
	 */
	EClass getInputData();

	/**
	 * Returns the meta object for the reference '{@link dMN.InputData#getDecision <em>Decision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Decision</em>'.
	 * @see dMN.InputData#getDecision()
	 * @see #getInputData()
	 * @generated
	 */
	EReference getInputData_Decision();

	/**
	 * Returns the meta object for class '{@link dMN.DecisionService <em>Decision Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Decision Service</em>'.
	 * @see dMN.DecisionService
	 * @generated
	 */
	EClass getDecisionService();

	/**
	 * Returns the meta object for the containment reference list '{@link dMN.DecisionService#getDecision <em>Decision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Decision</em>'.
	 * @see dMN.DecisionService#getDecision()
	 * @see #getDecisionService()
	 * @generated
	 */
	EReference getDecisionService_Decision();

	/**
	 * Returns the meta object for class '{@link dMN.KnowdlegeSource <em>Knowdlege Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Knowdlege Source</em>'.
	 * @see dMN.KnowdlegeSource
	 * @generated
	 */
	EClass getKnowdlegeSource();

	/**
	 * Returns the meta object for class '{@link dMN.Elements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elements</em>'.
	 * @see dMN.Elements
	 * @generated
	 */
	EClass getElements();

	/**
	 * Returns the meta object for the reference list '{@link dMN.Elements#getConnectionTarget <em>Connection Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Connection Target</em>'.
	 * @see dMN.Elements#getConnectionTarget()
	 * @see #getElements()
	 * @generated
	 */
	EReference getElements_ConnectionTarget();

	/**
	 * Returns the meta object for the reference list '{@link dMN.Elements#getConnectionSource <em>Connection Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Connection Source</em>'.
	 * @see dMN.Elements#getConnectionSource()
	 * @see #getElements()
	 * @generated
	 */
	EReference getElements_ConnectionSource();

	/**
	 * Returns the meta object for the attribute '{@link dMN.Elements#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see dMN.Elements#getName()
	 * @see #getElements()
	 * @generated
	 */
	EAttribute getElements_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link dMN.Elements#getConnectors <em>Connectors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Connectors</em>'.
	 * @see dMN.Elements#getConnectors()
	 * @see #getElements()
	 * @generated
	 */
	EReference getElements_Connectors();

	/**
	 * Returns the meta object for class '{@link dMN.Connectors <em>Connectors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connectors</em>'.
	 * @see dMN.Connectors
	 * @generated
	 */
	EClass getConnectors();

	/**
	 * Returns the meta object for the reference '{@link dMN.Connectors#getTo <em>To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>To</em>'.
	 * @see dMN.Connectors#getTo()
	 * @see #getConnectors()
	 * @generated
	 */
	EReference getConnectors_To();

	/**
	 * Returns the meta object for the reference '{@link dMN.Connectors#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>From</em>'.
	 * @see dMN.Connectors#getFrom()
	 * @see #getConnectors()
	 * @generated
	 */
	EReference getConnectors_From();

	/**
	 * Returns the meta object for class '{@link dMN.KnowledgeRequirement <em>Knowledge Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Knowledge Requirement</em>'.
	 * @see dMN.KnowledgeRequirement
	 * @generated
	 */
	EClass getKnowledgeRequirement();

	/**
	 * Returns the meta object for class '{@link dMN.InformationRequirement <em>Information Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Information Requirement</em>'.
	 * @see dMN.InformationRequirement
	 * @generated
	 */
	EClass getInformationRequirement();

	/**
	 * Returns the meta object for class '{@link dMN.AuthorityRequirement <em>Authority Requirement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Authority Requirement</em>'.
	 * @see dMN.AuthorityRequirement
	 * @generated
	 */
	EClass getAuthorityRequirement();

	/**
	 * Returns the meta object for class '{@link dMN.Decision <em>Decision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Decision</em>'.
	 * @see dMN.Decision
	 * @generated
	 */
	EClass getDecision();

	/**
	 * Returns the meta object for the reference list '{@link dMN.Decision#getInputDataDecision <em>Input Data Decision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Input Data Decision</em>'.
	 * @see dMN.Decision#getInputDataDecision()
	 * @see #getDecision()
	 * @generated
	 */
	EReference getDecision_InputDataDecision();

	/**
	 * Returns the meta object for class '{@link dMN.TextAnnotation <em>Text Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Text Annotation</em>'.
	 * @see dMN.TextAnnotation
	 * @generated
	 */
	EClass getTextAnnotation();

	/**
	 * Returns the meta object for class '{@link dMN.Association <em>Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association</em>'.
	 * @see dMN.Association
	 * @generated
	 */
	EClass getAssociation();

	/**
	 * Returns the meta object for the attribute '{@link dMN.Association#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see dMN.Association#getType()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_Type();

	/**
	 * Returns the meta object for enum '{@link dMN.typeAssociation <em>type Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>type Association</em>'.
	 * @see dMN.typeAssociation
	 * @generated
	 */
	EEnum gettypeAssociation();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DMNFactory getDMNFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link dMN.impl.DMNImpl <em>DMN</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.DMNImpl
		 * @see dMN.impl.DMNPackageImpl#getDMN()
		 * @generated
		 */
		EClass DMN = eINSTANCE.getDMN();

		/**
		 * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DMN__ELEMENTS = eINSTANCE.getDMN_Elements();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DMN__NAME = eINSTANCE.getDMN_Name();

		/**
		 * The meta object literal for the '{@link dMN.impl.BusinessKnowledgeImpl <em>Business Knowledge</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.BusinessKnowledgeImpl
		 * @see dMN.impl.DMNPackageImpl#getBusinessKnowledge()
		 * @generated
		 */
		EClass BUSINESS_KNOWLEDGE = eINSTANCE.getBusinessKnowledge();

		/**
		 * The meta object literal for the '{@link dMN.impl.InputDataImpl <em>Input Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.InputDataImpl
		 * @see dMN.impl.DMNPackageImpl#getInputData()
		 * @generated
		 */
		EClass INPUT_DATA = eINSTANCE.getInputData();

		/**
		 * The meta object literal for the '<em><b>Decision</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_DATA__DECISION = eINSTANCE.getInputData_Decision();

		/**
		 * The meta object literal for the '{@link dMN.impl.DecisionServiceImpl <em>Decision Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.DecisionServiceImpl
		 * @see dMN.impl.DMNPackageImpl#getDecisionService()
		 * @generated
		 */
		EClass DECISION_SERVICE = eINSTANCE.getDecisionService();

		/**
		 * The meta object literal for the '<em><b>Decision</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DECISION_SERVICE__DECISION = eINSTANCE.getDecisionService_Decision();

		/**
		 * The meta object literal for the '{@link dMN.impl.KnowdlegeSourceImpl <em>Knowdlege Source</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.KnowdlegeSourceImpl
		 * @see dMN.impl.DMNPackageImpl#getKnowdlegeSource()
		 * @generated
		 */
		EClass KNOWDLEGE_SOURCE = eINSTANCE.getKnowdlegeSource();

		/**
		 * The meta object literal for the '{@link dMN.impl.ElementsImpl <em>Elements</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.ElementsImpl
		 * @see dMN.impl.DMNPackageImpl#getElements()
		 * @generated
		 */
		EClass ELEMENTS = eINSTANCE.getElements();

		/**
		 * The meta object literal for the '<em><b>Connection Target</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEMENTS__CONNECTION_TARGET = eINSTANCE.getElements_ConnectionTarget();

		/**
		 * The meta object literal for the '<em><b>Connection Source</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEMENTS__CONNECTION_SOURCE = eINSTANCE.getElements_ConnectionSource();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENTS__NAME = eINSTANCE.getElements_Name();

		/**
		 * The meta object literal for the '<em><b>Connectors</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEMENTS__CONNECTORS = eINSTANCE.getElements_Connectors();

		/**
		 * The meta object literal for the '{@link dMN.impl.ConnectorsImpl <em>Connectors</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.ConnectorsImpl
		 * @see dMN.impl.DMNPackageImpl#getConnectors()
		 * @generated
		 */
		EClass CONNECTORS = eINSTANCE.getConnectors();

		/**
		 * The meta object literal for the '<em><b>To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTORS__TO = eINSTANCE.getConnectors_To();

		/**
		 * The meta object literal for the '<em><b>From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTORS__FROM = eINSTANCE.getConnectors_From();

		/**
		 * The meta object literal for the '{@link dMN.impl.KnowledgeRequirementImpl <em>Knowledge Requirement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.KnowledgeRequirementImpl
		 * @see dMN.impl.DMNPackageImpl#getKnowledgeRequirement()
		 * @generated
		 */
		EClass KNOWLEDGE_REQUIREMENT = eINSTANCE.getKnowledgeRequirement();

		/**
		 * The meta object literal for the '{@link dMN.impl.InformationRequirementImpl <em>Information Requirement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.InformationRequirementImpl
		 * @see dMN.impl.DMNPackageImpl#getInformationRequirement()
		 * @generated
		 */
		EClass INFORMATION_REQUIREMENT = eINSTANCE.getInformationRequirement();

		/**
		 * The meta object literal for the '{@link dMN.impl.AuthorityRequirementImpl <em>Authority Requirement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.AuthorityRequirementImpl
		 * @see dMN.impl.DMNPackageImpl#getAuthorityRequirement()
		 * @generated
		 */
		EClass AUTHORITY_REQUIREMENT = eINSTANCE.getAuthorityRequirement();

		/**
		 * The meta object literal for the '{@link dMN.impl.DecisionImpl <em>Decision</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.DecisionImpl
		 * @see dMN.impl.DMNPackageImpl#getDecision()
		 * @generated
		 */
		EClass DECISION = eINSTANCE.getDecision();

		/**
		 * The meta object literal for the '<em><b>Input Data Decision</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DECISION__INPUT_DATA_DECISION = eINSTANCE.getDecision_InputDataDecision();

		/**
		 * The meta object literal for the '{@link dMN.impl.TextAnnotationImpl <em>Text Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.TextAnnotationImpl
		 * @see dMN.impl.DMNPackageImpl#getTextAnnotation()
		 * @generated
		 */
		EClass TEXT_ANNOTATION = eINSTANCE.getTextAnnotation();

		/**
		 * The meta object literal for the '{@link dMN.impl.AssociationImpl <em>Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.impl.AssociationImpl
		 * @see dMN.impl.DMNPackageImpl#getAssociation()
		 * @generated
		 */
		EClass ASSOCIATION = eINSTANCE.getAssociation();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__TYPE = eINSTANCE.getAssociation_Type();

		/**
		 * The meta object literal for the '{@link dMN.typeAssociation <em>type Association</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dMN.typeAssociation
		 * @see dMN.impl.DMNPackageImpl#gettypeAssociation()
		 * @generated
		 */
		EEnum TYPE_ASSOCIATION = eINSTANCE.gettypeAssociation();

	}

} //DMNPackage
