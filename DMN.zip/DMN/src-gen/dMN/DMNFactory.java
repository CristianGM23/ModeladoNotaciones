/**
 */
package dMN;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see dMN.DMNPackage
 * @generated
 */
public interface DMNFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DMNFactory eINSTANCE = dMN.impl.DMNFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>DMN</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DMN</em>'.
	 * @generated
	 */
	DMN createDMN();

	/**
	 * Returns a new object of class '<em>Business Knowledge</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Business Knowledge</em>'.
	 * @generated
	 */
	BusinessKnowledge createBusinessKnowledge();

	/**
	 * Returns a new object of class '<em>Input Data</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input Data</em>'.
	 * @generated
	 */
	InputData createInputData();

	/**
	 * Returns a new object of class '<em>Decision Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Decision Service</em>'.
	 * @generated
	 */
	DecisionService createDecisionService();

	/**
	 * Returns a new object of class '<em>Knowdlege Source</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Knowdlege Source</em>'.
	 * @generated
	 */
	KnowdlegeSource createKnowdlegeSource();

	/**
	 * Returns a new object of class '<em>Connectors</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Connectors</em>'.
	 * @generated
	 */
	Connectors createConnectors();

	/**
	 * Returns a new object of class '<em>Knowledge Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Knowledge Requirement</em>'.
	 * @generated
	 */
	KnowledgeRequirement createKnowledgeRequirement();

	/**
	 * Returns a new object of class '<em>Information Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Information Requirement</em>'.
	 * @generated
	 */
	InformationRequirement createInformationRequirement();

	/**
	 * Returns a new object of class '<em>Authority Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Authority Requirement</em>'.
	 * @generated
	 */
	AuthorityRequirement createAuthorityRequirement();

	/**
	 * Returns a new object of class '<em>Decision</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Decision</em>'.
	 * @generated
	 */
	Decision createDecision();

	/**
	 * Returns a new object of class '<em>Text Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Text Annotation</em>'.
	 * @generated
	 */
	TextAnnotation createTextAnnotation();

	/**
	 * Returns a new object of class '<em>Association</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Association</em>'.
	 * @generated
	 */
	Association createAssociation();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	DMNPackage getDMNPackage();

} //DMNFactory
