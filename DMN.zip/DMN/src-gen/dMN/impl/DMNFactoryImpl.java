/**
 */
package dMN.impl;

import dMN.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DMNFactoryImpl extends EFactoryImpl implements DMNFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DMNFactory init() {
		try {
			DMNFactory theDMNFactory = (DMNFactory) EPackage.Registry.INSTANCE.getEFactory(DMNPackage.eNS_URI);
			if (theDMNFactory != null) {
				return theDMNFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new DMNFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case DMNPackage.DMN:
			return createDMN();
		case DMNPackage.BUSINESS_KNOWLEDGE:
			return createBusinessKnowledge();
		case DMNPackage.INPUT_DATA:
			return createInputData();
		case DMNPackage.DECISION_SERVICE:
			return createDecisionService();
		case DMNPackage.KNOWDLEGE_SOURCE:
			return createKnowdlegeSource();
		case DMNPackage.CONNECTORS:
			return createConnectors();
		case DMNPackage.KNOWLEDGE_REQUIREMENT:
			return createKnowledgeRequirement();
		case DMNPackage.INFORMATION_REQUIREMENT:
			return createInformationRequirement();
		case DMNPackage.AUTHORITY_REQUIREMENT:
			return createAuthorityRequirement();
		case DMNPackage.DECISION:
			return createDecision();
		case DMNPackage.TEXT_ANNOTATION:
			return createTextAnnotation();
		case DMNPackage.ASSOCIATION:
			return createAssociation();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case DMNPackage.TYPE_ASSOCIATION:
			return createtypeAssociationFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case DMNPackage.TYPE_ASSOCIATION:
			return converttypeAssociationToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMN createDMN() {
		DMNImpl dmn = new DMNImpl();
		return dmn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BusinessKnowledge createBusinessKnowledge() {
		BusinessKnowledgeImpl businessKnowledge = new BusinessKnowledgeImpl();
		return businessKnowledge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputData createInputData() {
		InputDataImpl inputData = new InputDataImpl();
		return inputData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DecisionService createDecisionService() {
		DecisionServiceImpl decisionService = new DecisionServiceImpl();
		return decisionService;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public KnowdlegeSource createKnowdlegeSource() {
		KnowdlegeSourceImpl knowdlegeSource = new KnowdlegeSourceImpl();
		return knowdlegeSource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Connectors createConnectors() {
		ConnectorsImpl connectors = new ConnectorsImpl();
		return connectors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public KnowledgeRequirement createKnowledgeRequirement() {
		KnowledgeRequirementImpl knowledgeRequirement = new KnowledgeRequirementImpl();
		return knowledgeRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InformationRequirement createInformationRequirement() {
		InformationRequirementImpl informationRequirement = new InformationRequirementImpl();
		return informationRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AuthorityRequirement createAuthorityRequirement() {
		AuthorityRequirementImpl authorityRequirement = new AuthorityRequirementImpl();
		return authorityRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Decision createDecision() {
		DecisionImpl decision = new DecisionImpl();
		return decision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TextAnnotation createTextAnnotation() {
		TextAnnotationImpl textAnnotation = new TextAnnotationImpl();
		return textAnnotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Association createAssociation() {
		AssociationImpl association = new AssociationImpl();
		return association;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public typeAssociation createtypeAssociationFromString(EDataType eDataType, String initialValue) {
		typeAssociation result = typeAssociation.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String converttypeAssociationToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNPackage getDMNPackage() {
		return (DMNPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static DMNPackage getPackage() {
		return DMNPackage.eINSTANCE;
	}

} //DMNFactoryImpl
