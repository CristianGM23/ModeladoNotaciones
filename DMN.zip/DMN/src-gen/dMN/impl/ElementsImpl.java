/**
 */
package dMN.impl;

import dMN.Connectors;
import dMN.DMNPackage;
import dMN.Elements;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elements</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dMN.impl.ElementsImpl#getConnectionTarget <em>Connection Target</em>}</li>
 *   <li>{@link dMN.impl.ElementsImpl#getConnectionSource <em>Connection Source</em>}</li>
 *   <li>{@link dMN.impl.ElementsImpl#getName <em>Name</em>}</li>
 *   <li>{@link dMN.impl.ElementsImpl#getConnectors <em>Connectors</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ElementsImpl extends MinimalEObjectImpl.Container implements Elements {
	/**
	 * The cached value of the '{@link #getConnectionTarget() <em>Connection Target</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectionTarget()
	 * @generated
	 * @ordered
	 */
	protected EList<Connectors> connectionTarget;

	/**
	 * The cached value of the '{@link #getConnectionSource() <em>Connection Source</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectionSource()
	 * @generated
	 * @ordered
	 */
	protected EList<Connectors> connectionSource;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getConnectors() <em>Connectors</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectors()
	 * @generated
	 * @ordered
	 */
	protected EList<Connectors> connectors;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElementsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DMNPackage.Literals.ELEMENTS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Connectors> getConnectionTarget() {
		if (connectionTarget == null) {
			connectionTarget = new EObjectWithInverseResolvingEList<Connectors>(Connectors.class, this,
					DMNPackage.ELEMENTS__CONNECTION_TARGET, DMNPackage.CONNECTORS__TO);
		}
		return connectionTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Connectors> getConnectionSource() {
		if (connectionSource == null) {
			connectionSource = new EObjectWithInverseResolvingEList<Connectors>(Connectors.class, this,
					DMNPackage.ELEMENTS__CONNECTION_SOURCE, DMNPackage.CONNECTORS__FROM);
		}
		return connectionSource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DMNPackage.ELEMENTS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Connectors> getConnectors() {
		if (connectors == null) {
			connectors = new EObjectContainmentEList<Connectors>(Connectors.class, this,
					DMNPackage.ELEMENTS__CONNECTORS);
		}
		return connectors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DMNPackage.ELEMENTS__CONNECTION_TARGET:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getConnectionTarget()).basicAdd(otherEnd, msgs);
		case DMNPackage.ELEMENTS__CONNECTION_SOURCE:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getConnectionSource()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DMNPackage.ELEMENTS__CONNECTION_TARGET:
			return ((InternalEList<?>) getConnectionTarget()).basicRemove(otherEnd, msgs);
		case DMNPackage.ELEMENTS__CONNECTION_SOURCE:
			return ((InternalEList<?>) getConnectionSource()).basicRemove(otherEnd, msgs);
		case DMNPackage.ELEMENTS__CONNECTORS:
			return ((InternalEList<?>) getConnectors()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DMNPackage.ELEMENTS__CONNECTION_TARGET:
			return getConnectionTarget();
		case DMNPackage.ELEMENTS__CONNECTION_SOURCE:
			return getConnectionSource();
		case DMNPackage.ELEMENTS__NAME:
			return getName();
		case DMNPackage.ELEMENTS__CONNECTORS:
			return getConnectors();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DMNPackage.ELEMENTS__CONNECTION_TARGET:
			getConnectionTarget().clear();
			getConnectionTarget().addAll((Collection<? extends Connectors>) newValue);
			return;
		case DMNPackage.ELEMENTS__CONNECTION_SOURCE:
			getConnectionSource().clear();
			getConnectionSource().addAll((Collection<? extends Connectors>) newValue);
			return;
		case DMNPackage.ELEMENTS__NAME:
			setName((String) newValue);
			return;
		case DMNPackage.ELEMENTS__CONNECTORS:
			getConnectors().clear();
			getConnectors().addAll((Collection<? extends Connectors>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DMNPackage.ELEMENTS__CONNECTION_TARGET:
			getConnectionTarget().clear();
			return;
		case DMNPackage.ELEMENTS__CONNECTION_SOURCE:
			getConnectionSource().clear();
			return;
		case DMNPackage.ELEMENTS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case DMNPackage.ELEMENTS__CONNECTORS:
			getConnectors().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DMNPackage.ELEMENTS__CONNECTION_TARGET:
			return connectionTarget != null && !connectionTarget.isEmpty();
		case DMNPackage.ELEMENTS__CONNECTION_SOURCE:
			return connectionSource != null && !connectionSource.isEmpty();
		case DMNPackage.ELEMENTS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case DMNPackage.ELEMENTS__CONNECTORS:
			return connectors != null && !connectors.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ElementsImpl
