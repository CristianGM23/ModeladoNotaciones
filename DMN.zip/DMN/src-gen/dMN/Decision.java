/**
 */
package dMN;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decision</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.Decision#getInputDataDecision <em>Input Data Decision</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getDecision()
 * @model
 * @generated
 */
public interface Decision extends Elements {
	/**
	 * Returns the value of the '<em><b>Input Data Decision</b></em>' reference list.
	 * The list contents are of type {@link dMN.InputData}.
	 * It is bidirectional and its opposite is '{@link dMN.InputData#getDecision <em>Decision</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Input Data Decision</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input Data Decision</em>' reference list.
	 * @see dMN.DMNPackage#getDecision_InputDataDecision()
	 * @see dMN.InputData#getDecision
	 * @model opposite="decision" required="true"
	 * @generated
	 */
	EList<InputData> getInputDataDecision();

} // Decision
