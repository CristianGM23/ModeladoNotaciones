/**
 */
package dMN;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elements</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.Elements#getConnectionTarget <em>Connection Target</em>}</li>
 *   <li>{@link dMN.Elements#getConnectionSource <em>Connection Source</em>}</li>
 *   <li>{@link dMN.Elements#getName <em>Name</em>}</li>
 *   <li>{@link dMN.Elements#getConnectors <em>Connectors</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getElements()
 * @model abstract="true"
 * @generated
 */
public interface Elements extends EObject {
	/**
	 * Returns the value of the '<em><b>Connection Target</b></em>' reference list.
	 * The list contents are of type {@link dMN.Connectors}.
	 * It is bidirectional and its opposite is '{@link dMN.Connectors#getTo <em>To</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connection Target</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection Target</em>' reference list.
	 * @see dMN.DMNPackage#getElements_ConnectionTarget()
	 * @see dMN.Connectors#getTo
	 * @model opposite="to"
	 * @generated
	 */
	EList<Connectors> getConnectionTarget();

	/**
	 * Returns the value of the '<em><b>Connection Source</b></em>' reference list.
	 * The list contents are of type {@link dMN.Connectors}.
	 * It is bidirectional and its opposite is '{@link dMN.Connectors#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connection Source</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection Source</em>' reference list.
	 * @see dMN.DMNPackage#getElements_ConnectionSource()
	 * @see dMN.Connectors#getFrom
	 * @model opposite="from"
	 * @generated
	 */
	EList<Connectors> getConnectionSource();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see dMN.DMNPackage#getElements_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link dMN.Elements#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Connectors</b></em>' containment reference list.
	 * The list contents are of type {@link dMN.Connectors}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connectors</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connectors</em>' containment reference list.
	 * @see dMN.DMNPackage#getElements_Connectors()
	 * @model containment="true"
	 * @generated
	 */
	EList<Connectors> getConnectors();

} // Elements
