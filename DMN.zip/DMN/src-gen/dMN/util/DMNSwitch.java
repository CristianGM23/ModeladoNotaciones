/**
 */
package dMN.util;

import dMN.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see dMN.DMNPackage
 * @generated
 */
public class DMNSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static DMNPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DMNSwitch() {
		if (modelPackage == null) {
			modelPackage = DMNPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case DMNPackage.DMN: {
			DMN dmn = (DMN) theEObject;
			T result = caseDMN(dmn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.BUSINESS_KNOWLEDGE: {
			BusinessKnowledge businessKnowledge = (BusinessKnowledge) theEObject;
			T result = caseBusinessKnowledge(businessKnowledge);
			if (result == null)
				result = caseElements(businessKnowledge);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.INPUT_DATA: {
			InputData inputData = (InputData) theEObject;
			T result = caseInputData(inputData);
			if (result == null)
				result = caseElements(inputData);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.DECISION_SERVICE: {
			DecisionService decisionService = (DecisionService) theEObject;
			T result = caseDecisionService(decisionService);
			if (result == null)
				result = caseElements(decisionService);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.KNOWDLEGE_SOURCE: {
			KnowdlegeSource knowdlegeSource = (KnowdlegeSource) theEObject;
			T result = caseKnowdlegeSource(knowdlegeSource);
			if (result == null)
				result = caseElements(knowdlegeSource);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.ELEMENTS: {
			Elements elements = (Elements) theEObject;
			T result = caseElements(elements);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.CONNECTORS: {
			Connectors connectors = (Connectors) theEObject;
			T result = caseConnectors(connectors);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.KNOWLEDGE_REQUIREMENT: {
			KnowledgeRequirement knowledgeRequirement = (KnowledgeRequirement) theEObject;
			T result = caseKnowledgeRequirement(knowledgeRequirement);
			if (result == null)
				result = caseConnectors(knowledgeRequirement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.INFORMATION_REQUIREMENT: {
			InformationRequirement informationRequirement = (InformationRequirement) theEObject;
			T result = caseInformationRequirement(informationRequirement);
			if (result == null)
				result = caseConnectors(informationRequirement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.AUTHORITY_REQUIREMENT: {
			AuthorityRequirement authorityRequirement = (AuthorityRequirement) theEObject;
			T result = caseAuthorityRequirement(authorityRequirement);
			if (result == null)
				result = caseConnectors(authorityRequirement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.DECISION: {
			Decision decision = (Decision) theEObject;
			T result = caseDecision(decision);
			if (result == null)
				result = caseElements(decision);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.TEXT_ANNOTATION: {
			TextAnnotation textAnnotation = (TextAnnotation) theEObject;
			T result = caseTextAnnotation(textAnnotation);
			if (result == null)
				result = caseElements(textAnnotation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DMNPackage.ASSOCIATION: {
			Association association = (Association) theEObject;
			T result = caseAssociation(association);
			if (result == null)
				result = caseConnectors(association);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>DMN</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>DMN</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDMN(DMN object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Business Knowledge</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Business Knowledge</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBusinessKnowledge(BusinessKnowledge object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input Data</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInputData(InputData object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Decision Service</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Decision Service</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDecisionService(DecisionService object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Knowdlege Source</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Knowdlege Source</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseKnowdlegeSource(KnowdlegeSource object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Elements</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Elements</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElements(Elements object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connectors</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connectors</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnectors(Connectors object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Knowledge Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Knowledge Requirement</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseKnowledgeRequirement(KnowledgeRequirement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Information Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Information Requirement</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInformationRequirement(InformationRequirement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Authority Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Authority Requirement</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAuthorityRequirement(AuthorityRequirement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Decision</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Decision</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDecision(Decision object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Text Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Text Annotation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTextAnnotation(TextAnnotation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Association</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Association</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAssociation(Association object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //DMNSwitch
