/**
 */
package dMN;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Association</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dMN.Association#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see dMN.DMNPackage#getAssociation()
 * @model
 * @generated
 */
public interface Association extends Connectors {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link dMN.typeAssociation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see dMN.typeAssociation
	 * @see #setType(typeAssociation)
	 * @see dMN.DMNPackage#getAssociation_Type()
	 * @model
	 * @generated
	 */
	typeAssociation getType();

	/**
	 * Sets the value of the '{@link dMN.Association#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see dMN.typeAssociation
	 * @see #getType()
	 * @generated
	 */
	void setType(typeAssociation value);

} // Association
