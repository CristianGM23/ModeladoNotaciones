/**
 */
package dMNTable.tests;

import dMNTable.Elements;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Elements</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class ElementsTest extends TestCase {

	/**
	 * The fixture for this Elements test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Elements fixture = null;

	/**
	 * Constructs a new Elements test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElementsTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Elements test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Elements fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Elements test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Elements getFixture() {
		return fixture;
	}

} //ElementsTest
